export type SelectiveCatchupPolicy =
  | "selective_axis_regret_catchup"
  | "selective_axis_regret_catchup_repair_incumbent_once"
  | "selective_axis_regret_catchup_periodic_initial"
  | "selective_axis_regret_catchup_periodic_repair"
  | "selective_axis_regret_catchup_value_map"
  | "selective_axis_regret_catchup_value_deferred_map"
  | "selective_axis_regret_catchup_value_deferred_initial"
  | "selective_axis_regret_catchup_value_deferred_pass_only"
  | "selective_axis_regret_catchup_value_deferred_prefix_gate"
  | "selective_axis_regret_catchup_value_initial"
  | "selective_axis_regret_catchup_value_initial_progress_10"
  | "selective_axis_regret_catchup_value_initial_expire_10"
  | "selective_axis_regret_catchup_value_initial_expire_10_stable_priority"
  | "selective_axis_regret_catchup_value_initial_expire_10_first_deficit_stop_005"
  | "selective_axis_regret_catchup_value_initial_expire_10_first_advantage_handoff"
  | "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q"
  | "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_empty_retry"
  | "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_after_first"
  | "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_before_last"
  | "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_positive_prefix"
  | "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_nonpositive_prefix"
  | "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_no_refill"
  | "selective_axis_regret_catchup_value_initial_expire_10_run_proof";

export type SelectiveBacktrackSignal =
  | "branch_regret"
  | "repair_incumbent_regret"
  | "periodic_exploration"
  | "value_exploration";

export type FrontierTraversalPolicy = "depth_first" | SelectiveCatchupPolicy;

export type FrontierTraversalLane =
  | "initial"
  | "snapshot"
  | "deferred_value"
  | "repair"
  | "resumed";

export const SELECTIVE_AXIS_REGRET_MIN_CONTACT_ADVANCE = 2;
export const SELECTIVE_AXIS_REGRET_MIN_LOSS_DELTA = 0.20;
export const SELECTIVE_REPAIR_INCUMBENT_MIN_LOSS_DELTA = 0.02;
export const SELECTIVE_PERIODIC_CONTACT_INTERVAL = 8;
export const SELECTIVE_PERIODIC_CONTACT_REWIND = 3;
export const SELECTIVE_PERIODIC_TERMINAL_RESERVE_FACTOR = 1.25;
export const SELECTIVE_PERIODIC_EXPLORATION_BUDGET_FRACTION = 0.15;
export const SELECTIVE_VALUE_MIN_CONTACT_ADVANCE = 3;
export const SELECTIVE_VALUE_DENSITY_FRAME_SCALE = 10_000;
export const SELECTIVE_VALUE_DENSITY_THRESHOLDS = [0.005, 0.01, 0.02, 0.04] as const;
export const SELECTIVE_VALUE_LIVE_DENSITY_THRESHOLD = 0.02;
export const SELECTIVE_VALUE_LIVE_MIN_GAP_PROGRESS = 0.10;
export const SELECTIVE_VALUE_FIRST_CHECKPOINT_DEFICIT_STOP = 0.005;
export const SELECTIVE_VALUE_PROBE_BREADTH_SCALE = 3 / 4;
/** Exact decimal representation of 15% * 3/4. */
export const SELECTIVE_VALUE_COUPLED_EXPLORATION_BUDGET_FRACTION = 0.1125;
export const SELECTIVE_DEFERRED_VALUE_ALLOWANCE_FRACTIONS = [0.15, 0.25, 0.40] as const;
export const SELECTIVE_DEFERRED_VALUE_MAP_MAX_ALLOWANCE_FRACTION = 0.40;
export const SELECTIVE_DEFERRED_VALUE_LIVE_ALLOWANCE_FRACTION = 0.40;
export const SELECTIVE_DEFERRED_PREFIX_GATE_CONTACT_HORIZON = 6;
export const SELECTIVE_DEFERRED_PREFIX_GATE_LOSS_DELTA = 0.05;
export const SELECTIVE_AXIS_REGRET_OPPORTUNITY_THRESHOLDS = [0.05, 0.10, 0.15, 0.20] as const;
export const REPAIR_INCUMBENT_REGRET_OPPORTUNITY_THRESHOLDS = [
  0,
  0.01,
  0.02,
  0.05,
  0.10,
] as const;
export const REPAIR_INCUMBENT_REGRET_OPPORTUNITY_CONTACT_ADVANCES = [
  2,
  3,
  4,
  5,
  6,
] as const;

export function parseFrontierTraversalPolicy(raw: string | undefined): FrontierTraversalPolicy {
  if (raw === undefined || raw === "") {
    return "selective_axis_regret_catchup_value_initial_expire_10";
  }
  if (raw === "selective-axis-regret-catchup") {
    return "selective_axis_regret_catchup";
  }
  if (raw === "selective-axis-regret-catchup-repair-incumbent-once") {
    return "selective_axis_regret_catchup_repair_incumbent_once";
  }
  if (raw === "selective-axis-regret-catchup-periodic-initial") {
    return "selective_axis_regret_catchup_periodic_initial";
  }
  if (raw === "selective-axis-regret-catchup-periodic-repair") {
    return "selective_axis_regret_catchup_periodic_repair";
  }
  if (raw === "selective-axis-regret-catchup-value-map") {
    return "selective_axis_regret_catchup_value_map";
  }
  if (raw === "selective-axis-regret-catchup-value-deferred-map") {
    return "selective_axis_regret_catchup_value_deferred_map";
  }
  if (raw === "selective-axis-regret-catchup-value-deferred-initial") {
    return "selective_axis_regret_catchup_value_deferred_initial";
  }
  if (raw === "selective-axis-regret-catchup-value-deferred-pass-only") {
    return "selective_axis_regret_catchup_value_deferred_pass_only";
  }
  if (raw === "selective-axis-regret-catchup-value-deferred-prefix-gate") {
    return "selective_axis_regret_catchup_value_deferred_prefix_gate";
  }
  if (raw === "selective-axis-regret-catchup-value-initial") {
    return "selective_axis_regret_catchup_value_initial";
  }
  if (raw === "selective-axis-regret-catchup-value-initial-progress-10") {
    return "selective_axis_regret_catchup_value_initial_progress_10";
  }
  if (raw === "selective-axis-regret-catchup-value-initial-expire-10") {
    return "selective_axis_regret_catchup_value_initial_expire_10";
  }
  if (raw === "selective-axis-regret-catchup-value-initial-expire-10-stable-priority") {
    return "selective_axis_regret_catchup_value_initial_expire_10_stable_priority";
  }
  if (raw ===
    "selective-axis-regret-catchup-value-initial-expire-10-first-deficit-stop-005") {
    return "selective_axis_regret_catchup_value_initial_expire_10_first_deficit_stop_005";
  }
  if (raw ===
    "selective-axis-regret-catchup-value-initial-expire-10-first-advantage-handoff") {
    return "selective_axis_regret_catchup_value_initial_expire_10_first_advantage_handoff";
  }
  if (raw ===
    "selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q") {
    return "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q";
  }
  if (raw ===
    "selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q-empty-retry") {
    return "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_empty_retry";
  }
  if (raw ===
    "selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q-after-first") {
    return "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_after_first";
  }
  if (raw ===
    "selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q-before-last") {
    return "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_before_last";
  }
  if (raw ===
    "selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q-positive-prefix") {
    return "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_positive_prefix";
  }
  if (raw ===
    "selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q-nonpositive-prefix") {
    return "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_nonpositive_prefix";
  }
  if (raw ===
    "selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q-no-refill") {
    return "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_no_refill";
  }
  if (raw === "selective-axis-regret-catchup-value-initial-expire-10-run-proof") {
    return "selective_axis_regret_catchup_value_initial_expire_10_run_proof";
  }
  if (raw === "0" || raw === "off" || raw === "dfs") return "depth_first";
  throw new Error(
    `LR_FRONTIER_POLICY must be dfs, selective-axis-regret-catchup, ` +
      `selective-axis-regret-catchup-repair-incumbent-once, ` +
      `selective-axis-regret-catchup-periodic-initial, or ` +
      `selective-axis-regret-catchup-periodic-repair, or ` +
      `selective-axis-regret-catchup-value-map, or ` +
      `selective-axis-regret-catchup-value-deferred-map, or ` +
      `selective-axis-regret-catchup-value-deferred-initial, or ` +
      `selective-axis-regret-catchup-value-deferred-pass-only, or ` +
      `selective-axis-regret-catchup-value-deferred-prefix-gate, or ` +
      `selective-axis-regret-catchup-value-initial, or ` +
      `selective-axis-regret-catchup-value-initial-progress-10, or ` +
      `selective-axis-regret-catchup-value-initial-expire-10, or ` +
      `selective-axis-regret-catchup-value-initial-expire-10-stable-priority, or ` +
      `selective-axis-regret-catchup-value-initial-expire-10-first-deficit-stop-005, or ` +
      `selective-axis-regret-catchup-value-initial-expire-10-first-advantage-handoff, or ` +
      `selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q, or ` +
      `selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q-empty-retry, or ` +
      `selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q-after-first, or ` +
      `selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q-before-last, or ` +
      `selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q-positive-prefix, or ` +
      `selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q-nonpositive-prefix, or ` +
      `selective-axis-regret-catchup-value-initial-expire-10-probe-breadth-3q-no-refill, or ` +
      `selective-axis-regret-catchup-value-initial-expire-10-run-proof; got ${raw}`,
  );
}

/** The live value lane ordinarily owns 15% of the search-policy budget. The
 * coupled arm scales that fund by the same exact factor as candidate breadth,
 * so cheaper nodes cannot silently buy additional speculative nodes. */
export function valueExplorationBudgetFraction(
  policy: FrontierTraversalPolicy,
): number {
  return policy ===
      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_no_refill"
    ? SELECTIVE_VALUE_COUPLED_EXPLORATION_BUDGET_FRACTION
    : SELECTIVE_PERIODIC_EXPLORATION_BUDGET_FRACTION;
}

export type SelectiveExplorationBudgetAssessment = {
  execution_remaining_frames: number;
  conservative_terminal_work_frames: number;
  estimated_probe_work_frames: number;
  terminal_reserve_frames: number;
  exploration_allowance_frames: number;
  exploration_spent_frames: number;
  exploration_remaining_frames: number;
  local_probe_allowance_frames: number;
  admitted: boolean;
  reason: "admitted" | "terminal_reserve" | "exploration_allowance";
};

/** Scale only an admitted value probe's already-resolved normal proposal
 * breadth. The production floor remains a hard scarce-budget safety floor. */
export function valueProbeCandidateCount(
  policy: FrontierTraversalPolicy,
  resolvedNCand: number,
  productionFloor: number,
): number {
  if (
    policy !== "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q" &&
    policy !==
      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_empty_retry" &&
    policy !==
      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_after_first" &&
    policy !==
      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_before_last" &&
    policy !==
      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_positive_prefix" &&
    policy !==
      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_nonpositive_prefix" &&
    policy !==
      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_no_refill"
  ) {
    return resolvedNCand;
  }
  return Math.max(
    productionFloor,
    Math.round(resolvedNCand * SELECTIVE_VALUE_PROBE_BREADTH_SCALE),
  );
}

/** Resolve positional breadth within one independently executed catch-up
 * route. `processedContactNodes` ignores non-contact bookkeeping nodes;
 * `remainingContactExpansions` includes the current contact expansion. */
export function valueProbeCandidateCountAtRoutePosition(
  policy: FrontierTraversalPolicy,
  resolvedNCand: number,
  productionFloor: number,
  processedContactNodes: number,
  remainingContactExpansions: number,
  latestPrefixAxisLossGain: number | null = null,
): number {
  if (
    !Number.isSafeInteger(processedContactNodes) || processedContactNodes < 0 ||
    !Number.isSafeInteger(remainingContactExpansions) || remainingContactExpansions < 1
  ) {
    throw new Error("value-probe route position must use non-negative processed and positive remaining contacts");
  }
  if (latestPrefixAxisLossGain !== null && !Number.isFinite(latestPrefixAxisLossGain)) {
    throw new Error("value-probe prefix gain must be finite or null");
  }
  if (
    policy ===
      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_after_first" &&
    processedContactNodes === 0
  ) return resolvedNCand;
  if (
    policy ===
      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_before_last" &&
    remainingContactExpansions === 1
  ) return resolvedNCand;
  if (
    policy ===
      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_positive_prefix" &&
    (processedContactNodes === 0 || latestPrefixAxisLossGain === null ||
      latestPrefixAxisLossGain <= 0)
  ) return resolvedNCand;
  if (
    policy ===
      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_nonpositive_prefix" &&
    (processedContactNodes === 0 || latestPrefixAxisLossGain === null ||
      latestPrefixAxisLossGain > 0)
  ) return resolvedNCand;
  return valueProbeCandidateCount(policy, resolvedNCand, productionFloor);
}

/** Full production breadth for the one policy that conditionally retries an
 * empty narrowed normal pool. Null is a hard guarantee that no other policy
 * widens, including the plain three-quarter arm. */
export function valueProbeEmptyFallbackCandidateCount(
  policy: FrontierTraversalPolicy,
  resolvedNCand: number,
): number | null {
  return policy ===
      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_empty_retry"
    ? resolvedNCand
    : null;
}

export type SelectivePeriodicOpportunity = {
  lane: FrontierTraversalLane;
  contact_ordinal: number;
  from_gap_index: number;
  branch_gap_index: number;
  alternative_gap_index: number;
  outcome:
    | "admitted"
    | "alternative_unavailable"
    | "execution_ceiling"
    | "terminal_reserve"
    | "exploration_allowance";
  conservative_deadline_margin: number | null;
  budget: SelectiveExplorationBudgetAssessment | null;
};

export type SelectiveValueOpportunityPoint = {
  lane: FrontierTraversalLane;
  contact_ordinal: number;
  from_gap_index: number;
  branch_gap_index: number;
  alternative_gap_index: number;
  contact_advance: number;
  gap_rewind: number;
  baseline_axis_loss: number;
  current_axis_loss: number;
  axis_loss_delta: number;
  /** Exact first-child comparison already present when the causal watch was
   * armed. Positive gain means the runner-up's first committed contact had
   * lower whole-prefix authored-axis loss than the preferred child. */
  branch_preferred_axis_loss: number | null;
  branch_alternative_axis_loss: number | null;
  branch_alternative_axis_loss_gain: number | null;
  /** Exact authored-axis window belonging only to the current route after the
   * watched branch point. This is evidence, not the production density. */
  current_divergent_suffix_axis_count: number | null;
  current_divergent_suffix_axis_sse: number | null;
  current_divergent_suffix_axis_loss: number | null;
  value_density_per_10k_estimated_frames: number;
  gap_progress: number | null;
  total_spent_frames: number;
  alternative_available: boolean;
  execution_ceiling_reached: boolean;
  budget: SelectiveExplorationBudgetAssessment;
};

export type SelectiveValueLiveOpportunity = {
  watch_id: number;
  outcome:
    | "admitted"
    | "ranked_out"
    | "production_priority"
    | "progress_expired"
    | "run_proof_sealed"
    | "alternative_unavailable"
    | "execution_ceiling"
    | "terminal_reserve"
    | "exploration_allowance";
  affordable_rank: number | null;
  point: SelectiveValueOpportunityPoint;
};

export type SelectiveValueOpportunity = {
  watch_id: number;
  threshold: number;
  crossing: SelectiveValueOpportunityPoint;
  first_admission: SelectiveValueOpportunityPoint | null;
};

export type SelectiveDeferredValueTerminalAssessment = {
  first_terminal_total_spent_frames: number;
  first_terminal_track_hash: string;
  on_incumbent_path: boolean;
  production_consumed: boolean;
  alternative_available: boolean;
  remaining_hard_budget_frames: number;
  remaining_repair_budget_frames: number;
  search_policy_budget_frames: number;
  exploration_allowance_frames: number;
  local_allowance_frames: number;
  estimated_suffix_work_frames: number;
  terminal_value_density_per_10k_estimated_frames: number;
  affordable: boolean;
  reason:
    | "admitted"
    | "not_incumbent_path"
    | "production_consumed"
    | "alternative_unavailable"
    | "hard_budget"
    | "repair_budget"
    | "exploration_allowance";
  affordable_rank: number | null;
};

export type SelectiveDeferredValueOpportunity = {
  watch_id: number;
  outcome: "progress_expired" | "alternative_unavailable_at_collection" | "collected";
  crossing: SelectiveValueOpportunityPoint;
  terminal: SelectiveDeferredValueTerminalAssessment | null;
};

export type SelectiveDeferredValueAxisComparison = {
  selected_axis_count: number;
  incumbent_axis_count: number;
  selected_axis_sse: number;
  incumbent_axis_sse: number;
  selected_axis_loss: number;
  incumbent_axis_loss: number;
  axis_loss_delta: number;
};

export type SelectiveDeferredValueCheckpoint = {
  selection_ordinal: number;
  selection_total_spent_frames: number;
  spent_frames_since_attempt_start: number;
  estimated_work_fraction_spent: number;
  gap_index: number;
  contact_ordinal: number;
  first_divergent_gap_index: number | null;
  comparable_contacts_since_divergence: number;
  skipped_contacts: number;
  frontier_lane: "pass" | "fallback";
  new_selected_gap_high_water: boolean;
  local_pass_frontier_size: number;
  local_fallback_frontier_size: number;
  whole_prefix: SelectiveDeferredValueAxisComparison;
  divergent_suffix: SelectiveDeferredValueAxisComparison | null;
  latest_comparable_contact_gap_index: number | null;
  latest_comparable_contact: SelectiveDeferredValueAxisComparison | null;
  divergent_suffix_axis_sse_by_axis: Record<string, {
    selected_observations: number;
    incumbent_observations: number;
    selected_sse: number;
    incumbent_sse: number;
    sse_delta: number;
  }>;
  on_offered_terminal_path: boolean | null;
};

export type SelectiveDeferredValueAttempt = {
  watch_id: number;
  affordable_rank: number;
  start_gap_index: number;
  start_total_spent_frames: number;
  end_total_spent_frames: number;
  estimated_suffix_work_frames: number;
  local_allowance_frames: number;
  execution_ceiling_frames: number;
  outcome:
    | "terminal_reached"
    | "fallback_frontier_return"
    | "prefix_gate_stop"
    | "atomic_budget_yield"
    | "frontier_exhausted"
    | "execution_ceiling";
  nodes_processed: number;
  atomic_node_frames: number[];
  ranked_option_calls: number;
  requested_normal_proposals: number;
  candidate_geometry_evaluations: number;
  tail_completion_attempts: number;
  terminal_node_evaluations: number;
  register_improvements: number;
  terminal_register_improvements: number;
  remaining_pass_nodes_returned: number;
  remaining_fallback_nodes_returned: number;
  budget_remaining_before_yield: number | null;
  estimated_next_node_frames: number | null;
  progress_checkpoints: SelectiveDeferredValueCheckpoint[];
  pass_frontier_gate: {
    decision: "not_reached" | "fallback_return";
    checkpoint: null | {
      selection_ordinal: number;
      selection_total_spent_frames: number;
      spent_frames_since_attempt_start: number;
      remaining_local_allowance_frames: number;
      gap_index: number;
      contact_ordinal: number;
      skipped_contacts: number;
      local_pass_frontier_size: number;
      local_fallback_frontier_size: number;
    };
  } | null;
  prefix_gate: {
    contact_horizon: number;
    axis_loss_delta_threshold: number;
    decision: "not_reached" | "continue" | "stop";
    checkpoint: null | {
      selection_ordinal: number;
      selection_total_spent_frames: number;
      spent_frames_since_attempt_start: number;
      estimated_work_fraction_spent: number;
      remaining_local_allowance_frames: number;
      gap_index: number;
      contact_ordinal: number;
      comparable_contacts_since_divergence: number;
      divergent_suffix: SelectiveDeferredValueAxisComparison;
    };
  } | null;
};

export type SelectiveDeferredValueDecision<Node extends object> = {
  watchId: number;
  current: Node;
  alternative: Node;
  crossing: SelectiveValueOpportunityPoint;
  terminal: SelectiveDeferredValueTerminalAssessment;
};

export function catchupAlternativeHasSufficientGain(
  currentAxisLoss: number,
  alternativeAxisLoss: number,
): boolean {
  return currentAxisLoss > alternativeAxisLoss;
}

export function catchupAlternativeHasStablePriority(
  currentAxisLoss: number,
  alternativeAxisLoss: number,
  allCheckpointGainsPositive: boolean,
): boolean {
  return allCheckpointGainsPositive &&
    catchupAlternativeHasSufficientGain(currentAxisLoss, alternativeAxisLoss);
}

type AxisRegretWatch<Node extends object> = {
  watchId: number;
  alternative: Node;
  additionalAlternatives: readonly Node[];
  branchContactOrdinal: number;
  branchGapIndex: number;
  baselineAxisLoss: number;
  branchPreferredAxisLoss: number | null;
  branchAlternativeAxisLoss: number | null;
  branchAlternativeAxisLossGain: number | null;
  used: boolean;
  signalCrossed: boolean;
  deadlineSuppressionRecorded: boolean;
  opportunityCrossedMask: number;
  opportunityAdmissibleMask: number;
  repairIncumbentOpportunityCrossedMask: number;
  repairIncumbentOpportunityAdmissibleMask: number;
  repairIncumbentMaturityOpportunityCrossedMask: number;
  repairIncumbentMaturityOpportunityAdmissibleMask: number;
  repairIncumbentAttemptLimitSuppressionRecorded: boolean;
  valueOpportunityCrossedMask: number;
  valueOpportunityAdmissibleMask: number;
  valueOpportunityRecordIndices: Array<number | null>;
  valueLiveCrossed: boolean;
  valueLiveProgressSuppressionRecorded: boolean;
  deferredValueCrossed: boolean;
};

type WatchLink<Node extends object> = {
  watch: AxisRegretWatch<Node>;
  parent: WatchLink<Node> | null;
};

type DeferredValueCandidate<Node extends object> = {
  watch: AxisRegretWatch<Node>;
  current: Node;
  recordIndex: number;
  axisLossDelta: number;
};

export type SelectiveBacktrackDecision<Node extends object> = {
  alternative: Node;
  alternatives: readonly Node[];
  eventIndex: number;
  branchGapIndex: number;
  fromGapIndex: number;
  contactAdvance: number;
  gapRewind: number;
  axisLossDelta: number;
  triggerAxisLoss: number;
  triggerSignal: SelectiveBacktrackSignal;
  incumbentAxisLoss: number | null;
  incumbentAxisLossDelta: number | null;
  repairAttemptIndex: number | null;
  explorationBudget: SelectiveExplorationBudgetAssessment | null;
};

export type SelectiveAdmissibleRewindChoice = {
  branch_gap_index: number;
  alternative_gap_index: number;
  contact_advance: number;
  gap_rewind: number;
  axis_loss_delta: number;
  conservative_deadline_margin: number;
};

export type SelectiveCatchupOutcome =
  | "alternative_selected"
  | "current_selected"
  | "probe_dead_end"
  | "probe_deferred"
  | "probe_budget_yield"
  | "probe_first_deficit_stop"
  | "probe_first_advantage_handoff"
  | "execution_ceiling";

export type SelectiveCatchupProbeOutcome =
  | "reached_target"
  | "probe_dead_end"
  | "probe_deferred"
  | "probe_budget_yield"
  | "probe_first_deficit_stop"
  | "probe_first_advantage_handoff"
  | "execution_ceiling";

export type SelectiveCatchupProbeResult = {
  route_ordinal: number;
  route_kind: "causal_alternative";
  alternative_ordinal: number;
  outcome: SelectiveCatchupProbeOutcome;
  end_gap_index: number;
  probe_nodes_processed: number;
  probe_frames: number;
  ranked_option_calls: number;
  requested_normal_proposals: number;
  candidate_geometry_evaluations: number;
  normal_empty_full_width_retry_attempts: number;
  normal_empty_full_width_retry_successes: number;
  normal_empty_full_width_retry_requested_proposals: number;
  /** Sum of (full width - narrow width) across retry calls. This is the
   * requested deterministic-prefix increment, not necessarily fresh sampling. */
  normal_empty_full_width_retry_incremental_requested_proposals: number;
  normal_empty_full_width_retry_candidate_geometry_evaluations: number;
  normal_empty_full_width_retry_frames: number;
  /** Actual primary normal nCand for each processed atomic node; null means the
   * node did not perform a contact-pool expansion. Aligned with atomic_node_frames. */
  atomic_node_primary_normal_requested_proposals: Array<number | null>;
  atomic_node_starting_prefix_axis_loss_gain: Array<number | null>;
  atomic_node_frames: number[];
  tail_completion_attempts: number;
  budget_allowance_frames: number | null;
  budget_remaining_before_yield: number | null;
  estimated_next_node_frames: number | null;
  axis_loss: number | null;
  local_fallback_choices: SelectiveLocalFallbackChoice[];
};

export type SelectiveLocalFallbackChoice = {
  choice_ordinal: number;
  gap_index: number;
  remaining_gap_advance: number;
  current_relative_axis_loss_gain: number;
  conservative_deadline_margin: number;
};

export type SelectiveBacktrackingStats = {
  policy: SelectiveCatchupPolicy;
  min_contact_advance: number;
  min_axis_loss_delta: number;
  catchup_axis_loss_gain_threshold: number;
  catchup_priority_rule: "endpoint_gain" | "all_checkpoints_positive";
  value_probe_stop_rule:
    | "equal_depth_or_budget"
    | "first_pre_target_deficit_005"
    | "first_pre_target_advantage";
  value_probe_first_checkpoint_deficit_threshold: number | null;
  value_probe_first_checkpoint_advantage_threshold: number | null;
  value_probe_candidate_breadth_rule:
    | "production"
    | "three_quarter_after_floor"
    | "three_quarter_after_floor_empty_full_retry"
    | "full_first_then_three_quarter_after_floor"
    | "three_quarter_after_floor_then_full_last"
    | "full_first_then_three_quarter_while_prefix_positive"
    | "full_first_then_three_quarter_while_prefix_nonpositive";
  value_probe_candidate_breadth_scale: number;
  catchup_endpoint_winners_suppressed_unstable: number;
  mature_axis_loss_delta_max: number;
  regret_opportunities_by_min_axis_loss_delta: Record<
    string,
    { crossed_watches: number; admissible_watches: number }
  >;
  repair_incumbent_regret_opportunities_by_min_axis_loss_delta: Record<
    string,
    { crossed_watches: number; admissible_watches: number }
  >;
  repair_incumbent_regret_opportunities_by_min_contact_advance: Record<
    string,
    { crossed_watches: number; admissible_watches: number }
  >;
  repair_incumbent_axis_loss_delta_max: number;
  repair_incumbent_max_backtracks_per_attempt: number;
  repair_incumbent_attempt_limit_suppressed_watches: number;
  periodic_contact_interval: number;
  periodic_contact_rewind: number;
  periodic_terminal_reserve_factor: number;
  periodic_exploration_budget_fraction: number;
  periodic_schedule_checks: number;
  periodic_exact_rewind_opportunities: number;
  periodic_admitted: number;
  periodic_alternative_unavailable: number;
  periodic_execution_ceiling_suppressed: number;
  periodic_terminal_reserve_suppressed: number;
  periodic_exploration_allowance_suppressed: number;
  periodic_probe_frames: number;
  periodic_probe_nodes_processed: number;
  periodic_opportunities: SelectivePeriodicOpportunity[];
  value_min_contact_advance: number;
  value_density_frame_scale: number;
  value_density_thresholds: number[];
  value_opportunities_by_density: Record<
    string,
    { crossed_watches: number; admissible_watches: number }
  >;
  value_opportunities: SelectiveValueOpportunity[];
  value_live_density_threshold: number;
  value_live_min_gap_progress: number;
  value_live_exploration_budget_fraction: number;
  value_live_progress_suppressed_watches: number;
  value_live_progress_expired_watches: number;
  value_live_run_proof_state:
    | "disabled"
    | "awaiting_first_tournament"
    | "first_tournament_reached_target"
    | "sealed_after_failed_first_tournament";
  value_live_run_proof_first_event_index: number | null;
  value_live_run_proof_first_outcome: SelectiveCatchupOutcome | null;
  value_live_run_proof_first_reached_target: boolean | null;
  value_live_run_proof_sealed_opportunities: number;
  value_live_crossings: number;
  value_live_admitted: number;
  value_live_ranked_out: number;
  value_live_production_priority: number;
  value_live_alternative_unavailable: number;
  value_live_execution_ceiling_suppressed: number;
  value_live_terminal_reserve_suppressed: number;
  value_live_exploration_allowance_suppressed: number;
  value_live_probe_frames: number;
  value_live_probe_nodes_processed: number;
  value_live_probe_budget_yields: number;
  value_live_opportunities: SelectiveValueLiveOpportunity[];
  deferred_value_density_threshold: number;
  deferred_value_min_gap_progress: number;
  deferred_value_allowance_fractions: number[];
  deferred_value_map_max_allowance_fraction: number;
  deferred_value_crossings: number;
  deferred_value_progress_expired: number;
  deferred_value_alternative_unavailable_at_collection: number;
  deferred_value_collected: number;
  deferred_value_assessed: number;
  deferred_value_incumbent_path: number;
  deferred_value_production_consumed: number;
  deferred_value_alternative_unavailable_at_terminal: number;
  deferred_value_affordable: number;
  deferred_value_first_terminal_total_spent_frames: number | null;
  deferred_value_first_terminal_track_hash: string | null;
  deferred_value_opportunities: SelectiveDeferredValueOpportunity[];
  deferred_value_attempts: SelectiveDeferredValueAttempt[];
  contact_expansions_observed: number;
  branch_watches_armed: number;
  branch_watches_by_alternative_count: Record<string, number>;
  mature_watch_checks: number;
  loss_threshold_crossings: number;
  deadline_suppressed_crossings: number;
  execution_ceiling_suppressed_crossings: number;
  unavailable_alternatives: number;
  selective_backtracks: number;
  selective_backtracks_by_signal: Record<SelectiveBacktrackSignal, number>;
  selective_backtracks_with_multiple_admissible_rewind_choices: number;
  admissible_rewind_choice_count_sum: number;
  admissible_rewind_choice_count_max: number;
  selective_backtracks_with_additional_sibling_available: number;
  additional_siblings_available_at_selective_backtrack_sum: number;
  additional_siblings_available_at_selective_backtrack_max: number;
  suspended_continuations_resumed: number;
  catchup_completed: number;
  catchup_alternative_selected: number;
  catchup_current_selected: number;
  catchup_probe_dead_ends: number;
  catchup_probe_deferred: number;
  catchup_probe_budget_yields: number;
  catchup_probe_first_deficit_stops: number;
  catchup_probe_first_advantage_handoffs: number;
  catchup_first_advantage_handoffs_selected: number;
  catchup_execution_ceiling_stops: number;
  catchup_probe_attempts: number;
  catchup_probe_target_reaches: number;
  catchup_probes_with_local_fallback_choice: number;
  catchup_probes_with_positive_local_fallback_choice: number;
  catchup_local_fallback_choice_count_sum: number;
  catchup_positive_local_fallback_choice_count_sum: number;
  catchup_local_fallback_choice_count_max: number;
  catchup_additional_probe_attempts: number;
  catchup_additional_probe_target_reaches: number;
  catchup_tournaments_with_additional_probe: number;
  catchup_additional_alternative_selected: number;
  catchup_probe_nodes_processed: number;
  catchup_probe_frames: number;
  route_lease_audit_enabled: boolean;
  route_lease_rollback_enabled: boolean;
  route_lease_revalidation_enabled: boolean;
  route_lease_renewal_audit_enabled: boolean;
  route_lease_revalidation_lineage_reset_enabled: boolean;
  route_lease_audits_started: number;
  route_lease_audits_selected: number;
  route_lease_audits_with_loss_crossing: number;
  route_lease_rollbacks_admitted: number;
  route_lease_rollbacks_executed: number;
  route_lease_rollbacks_incumbent_unavailable: number;
  route_lease_rollbacks_terminal_reserve_suppressed: number;
  route_lease_revalidations_eligible: number;
  route_lease_revalidations_admitted: number;
  route_lease_revalidations_started: number;
  route_lease_revalidations_incumbent_unavailable: number;
  route_lease_revalidations_terminal_reserve_suppressed: number;
  route_lease_revalidations_probe_allowance_suppressed: number;
  route_lease_revalidations_target_reached: number;
  route_lease_revalidations_current_selected: number;
  route_lease_revalidations_incumbent_selected: number;
  route_lease_revalidations_probe_dead_ends: number;
  route_lease_revalidations_probe_deferred: number;
  route_lease_revalidations_probe_budget_yields: number;
  route_lease_revalidations_execution_ceiling_stops: number;
  route_lease_revalidation_probe_nodes_processed: number;
  route_lease_revalidation_probe_frames: number;
  route_lease_renewal_audits_started: number;
  route_lease_renewal_audits_with_loss_crossing: number;
  route_lease_revalidation_lineage_resets: number;
  route_lease_revalidation_selected_watch_links_cleared: number;
  route_lease_revalidation_displaced_watch_links_cleared: number;
  route_lease_revalidation_unique_watch_ids_cleared: number;
  route_lease_audits: SelectiveRouteLeaseAudit[];
  axis_loss_delta_sum: number;
  axis_loss_delta_max: number;
  contact_advance_sum: number;
  contact_advance_max: number;
  gap_rewind_sum: number;
  gap_rewind_max: number;
  selective_backtracks_by_lane: Record<FrontierTraversalLane, number>;
  events: SelectiveBacktrackingEvent[];
};

export type SelectiveBacktrackingEvent = {
  watch_id: number;
  lane: FrontierTraversalLane;
  trigger_signal: SelectiveBacktrackSignal;
  branch_gap_index: number;
  from_gap_index: number;
  alternative_gap_index: number;
  additional_siblings_available: number;
  catchup_alternatives_requested: number;
  contact_advance: number;
  gap_rewind: number;
  baseline_axis_loss: number;
  trigger_axis_loss: number;
  axis_loss_delta: number;
  branch_preferred_axis_loss: number | null;
  branch_alternative_axis_loss: number | null;
  branch_alternative_axis_loss_gain: number | null;
  current_divergent_suffix_axis_count: number | null;
  current_divergent_suffix_axis_sse: number | null;
  current_divergent_suffix_axis_loss: number | null;
  incumbent_axis_loss: number | null;
  incumbent_axis_loss_delta: number | null;
  repair_attempt_index: number | null;
  periodic_budget: SelectiveExplorationBudgetAssessment | null;
  value_budget: SelectiveExplorationBudgetAssessment | null;
  admissible_rewind_choices: SelectiveAdmissibleRewindChoice[];
  alternative_conservative_deadline_margin: number;
  trigger_total_spent_frames: number;
  resumed_total_spent_frames: number | null;
  first_advantage_handoff_total_spent_frames: number | null;
  catchup_outcome: SelectiveCatchupOutcome | null;
  catchup_end_gap_index: number | null;
  catchup_probe_nodes_processed: number;
  catchup_probe_frames: number;
  catchup_axis_loss: number | null;
  catchup_axis_loss_gain: number | null;
  catchup_best_alternative_all_checkpoints_positive: boolean | null;
  catchup_endpoint_winner_priority_suppressed: boolean;
  catchup_selected_alternative_ordinal: number | null;
  catchup_selected_route_ordinal: number | null;
  catchup_probe_results: SelectiveCatchupProbeResult[];
  catchup_checkpoints: SelectiveCatchupCheckpoint[];
};

export type SelectiveCatchupCheckpoint = {
  route_ordinal: number;
  route_kind: SelectiveCatchupProbeResult["route_kind"];
  alternative_ordinal: number;
  gap_index: number;
  contact_advance: number;
  probe_nodes_processed: number;
  probe_frames: number;
  current_axis_loss: number;
  alternative_axis_loss: number;
  alternative_axis_loss_gain: number;
};

export type SelectiveRouteLeaseAxisWindow = {
  axis_count: number;
  axis_sse: number;
  axis_loss: number;
};

export type SelectiveRouteLeaseCheckpoint = {
  selection_ordinal: number;
  gap_index: number;
  total_spent_frames: number;
  whole_prefix: SelectiveRouteLeaseAxisWindow;
  divergent_suffix: SelectiveRouteLeaseAxisWindow;
  loss_excess_over_displaced_incumbent: number;
  displaced_incumbent_available: boolean;
  displaced_incumbent_conservative_deadline_margin: number;
  displaced_incumbent_affordable_with_reserve: boolean;
};

export type SelectiveRouteLeaseAudit = {
  origin: "initial_tournament" | "revalidation_renewal";
  parent_audit_index: number | null;
  event_index: number;
  takeover_gap_index: number;
  selected_route_ordinal: number | null;
  selected_alternative_ordinal: number | null;
  selected_takeover: SelectiveRouteLeaseAxisWindow;
  displaced_incumbent_takeover: SelectiveRouteLeaseAxisWindow;
  takeover_axis_loss_gain: number;
  selected_total_spent_frames: number | null;
  selections_observed: number;
  deepest_gap_index: number;
  first_loss_crossing: SelectiveRouteLeaseCheckpoint | null;
  rollback_disposition:
    | "audit_only"
    | "displaced_incumbent_unavailable"
    | "terminal_reserve"
    | "admitted"
    | "executed"
    | null;
  rollback_total_spent_frames: number | null;
  revalidation_disposition:
    | "displaced_incumbent_unavailable"
    | "terminal_reserve"
    | "probe_allowance"
    | "eligible"
    | "started"
    | null;
  revalidation: {
    target_gap_index: number;
    start_total_spent_frames: number;
    probe_allowance_frames: number;
    estimated_probe_work_frames: number;
    terminal_reserve_frames: number;
    execution_remaining_frames: number;
    preflight_estimated_next_node_frames: number;
    end_total_spent_frames: number;
    probe_nodes_processed: number;
    probe_frames: number;
    outcome:
      | "current_selected"
      | "incumbent_selected"
      | "probe_dead_end"
      | "probe_deferred"
      | "probe_budget_yield"
      | "execution_ceiling";
    current_axis_loss: number | null;
    incumbent_axis_loss: number | null;
    current_axis_count: number | null;
    incumbent_axis_count: number | null;
    current_axis_sse: number | null;
    incumbent_axis_sse: number | null;
  } | null;
  lineage_reset: {
    total_spent_frames: number;
    selected_watch_links_cleared: number;
    displaced_watch_links_cleared: number;
    unique_watch_ids_cleared: number;
  } | null;
  checkpoints: SelectiveRouteLeaseCheckpoint[];
  end_reason:
    | "terminal"
    | "displaced_incumbent_resumed"
    | "revalidation_current_selected"
    | "revalidation_incumbent_selected"
    | "revalidation_probe_stopped"
    | "displaced_route_selected"
    | "superseded_by_selective_tournament"
    | null;
  end_total_spent_frames: number | null;
};

function emptyLaneCounter(): Record<FrontierTraversalLane, number> {
  return { initial: 0, snapshot: 0, deferred_value: 0, repair: 0, resumed: 0 };
}

function emptySignalCounter(): Record<SelectiveBacktrackSignal, number> {
  return {
    branch_regret: 0,
    repair_incumbent_regret: 0,
    periodic_exploration: 0,
    value_exploration: 0,
  };
}

function emptyRegretOpportunityCounter(): SelectiveBacktrackingStats[
  "regret_opportunities_by_min_axis_loss_delta"
] {
  return Object.fromEntries(SELECTIVE_AXIS_REGRET_OPPORTUNITY_THRESHOLDS.map((threshold) => [
    threshold.toFixed(2),
    { crossed_watches: 0, admissible_watches: 0 },
  ]));
}

function emptyRepairIncumbentRegretOpportunityCounter(): SelectiveBacktrackingStats[
  "repair_incumbent_regret_opportunities_by_min_axis_loss_delta"
] {
  return Object.fromEntries(REPAIR_INCUMBENT_REGRET_OPPORTUNITY_THRESHOLDS.map((threshold) => [
    threshold.toFixed(2),
    { crossed_watches: 0, admissible_watches: 0 },
  ]));
}

function emptyRepairIncumbentMaturityOpportunityCounter(): SelectiveBacktrackingStats[
  "repair_incumbent_regret_opportunities_by_min_contact_advance"
] {
  return Object.fromEntries(REPAIR_INCUMBENT_REGRET_OPPORTUNITY_CONTACT_ADVANCES.map(
    (advance) => [String(advance), { crossed_watches: 0, admissible_watches: 0 }],
  ));
}

function emptyValueOpportunityCounter(): SelectiveBacktrackingStats[
  "value_opportunities_by_density"
] {
  return Object.fromEntries(SELECTIVE_VALUE_DENSITY_THRESHOLDS.map((threshold) => [
    threshold.toFixed(3),
    { crossed_watches: 0, admissible_watches: 0 },
  ]));
}

function validateRouteLeaseAxisWindow(
  window: SelectiveRouteLeaseAxisWindow,
  label: string,
): void {
  if (
    !Number.isSafeInteger(window.axis_count) || window.axis_count < 0 ||
    !Number.isFinite(window.axis_sse) || window.axis_sse < 0 ||
    !Number.isFinite(window.axis_loss) || window.axis_loss < 0
  ) throw new Error(`${label} has invalid authored-axis evidence`);
}

function approximatelyEqual(left: number, right: number): boolean {
  return Math.abs(left - right) <= 1e-10 * Math.max(1, Math.abs(left), Math.abs(right));
}

/**
 * Compile-local signal and attribution state for the bounded-catch-up strategy.
 *
 * The controller knows no frontier representation and performs no mutation.
 * It only carries causal branch-watch lineage, evaluates the regret signal,
 * and returns the exact queued sibling that the frontier scheduler should
 * probe. This keeps trigger policy independent from catch-up scheduling and
 * equal-depth selection.
 */
export class SelectiveAxisRegretController<Node extends object> {
  readonly policy: SelectiveCatchupPolicy;

  private readonly gapIndexOf: (node: Node) => number;
  private readonly lineage = new WeakMap<Node, WatchLink<Node> | null>();
  private readonly suspended = new WeakMap<Node, number>();
  private readonly firstAdvantageHandoffs = new WeakMap<Node, number>();
  private readonly routeLeaseAuditEnabled: boolean;
  private readonly routeLeaseRollbackEnabled: boolean;
  private readonly routeLeaseRevalidationEnabled: boolean;
  private readonly routeLeaseRenewalAuditEnabled: boolean;
  private readonly routeLeaseResetLineageEnabled: boolean;
  private readonly routeLeaseNodes = new WeakMap<Node, number>();
  private readonly routeLeaseDisplacedNodes = new WeakMap<Node, number>();
  private readonly pendingRouteLeaseRollbacks = new WeakMap<Node, number>();
  private readonly pendingRouteLeaseRevalidations = new WeakMap<Node, number>();
  private readonly routeLeaseIncumbents = new Map<number, Node>();
  private readonly repairAttemptsWithIncumbentBacktrack = new Set<number>();
  private readonly deferredValueCandidates: Array<DeferredValueCandidate<Node>> = [];
  private readonly stats: SelectiveBacktrackingStats;
  private nextWatchId = 1;
  private deferredValueSealed = false;

  constructor(
    gapIndexOf: (node: Node) => number,
    options: {
      policy?: SelectiveCatchupPolicy;
      routeLeaseAudit?: boolean;
      routeLeaseRollback?: boolean;
      routeLeaseRevalidation?: boolean;
      routeLeaseRenewalAudit?: boolean;
      routeLeaseResetLineage?: boolean;
    } = {},
  ) {
    this.gapIndexOf = gapIndexOf;
    this.policy = options.policy ?? "selective_axis_regret_catchup";
    this.routeLeaseRollbackEnabled = options.routeLeaseRollback === true;
    this.routeLeaseRevalidationEnabled = options.routeLeaseRevalidation === true;
    this.routeLeaseRenewalAuditEnabled = options.routeLeaseRenewalAudit === true;
    this.routeLeaseResetLineageEnabled = options.routeLeaseResetLineage === true;
    if (this.routeLeaseRenewalAuditEnabled && !this.routeLeaseRevalidationEnabled) {
      throw new Error("route-lease renewal audit requires revalidation");
    }
    if (this.routeLeaseResetLineageEnabled && !this.routeLeaseRevalidationEnabled) {
      throw new Error("route-lease lineage reset requires revalidation");
    }
    if (this.routeLeaseRollbackEnabled && this.routeLeaseRevalidationEnabled) {
      throw new Error("route-lease rollback and revalidation are mutually exclusive");
    }
    this.routeLeaseAuditEnabled = options.routeLeaseAudit === true ||
      this.routeLeaseRollbackEnabled || this.routeLeaseRevalidationEnabled;
    this.stats = {
      policy: this.policy,
      min_contact_advance: SELECTIVE_AXIS_REGRET_MIN_CONTACT_ADVANCE,
      min_axis_loss_delta: SELECTIVE_AXIS_REGRET_MIN_LOSS_DELTA,
      catchup_axis_loss_gain_threshold: 0,
      catchup_priority_rule:
        this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_stable_priority"
          ? "all_checkpoints_positive"
          : "endpoint_gain",
      value_probe_stop_rule:
        this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_first_deficit_stop_005"
          ? "first_pre_target_deficit_005"
          : this.policy ===
              "selective_axis_regret_catchup_value_initial_expire_10_first_advantage_handoff"
            ? "first_pre_target_advantage"
          : "equal_depth_or_budget",
      value_probe_first_checkpoint_deficit_threshold:
        this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_first_deficit_stop_005"
          ? SELECTIVE_VALUE_FIRST_CHECKPOINT_DEFICIT_STOP
          : null,
      value_probe_first_checkpoint_advantage_threshold:
        this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_first_advantage_handoff"
          ? 0
          : null,
      value_probe_candidate_breadth_rule:
        this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_empty_retry"
          ? "three_quarter_after_floor_empty_full_retry"
          : this.policy ===
              "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_after_first"
            ? "full_first_then_three_quarter_after_floor"
            : this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_before_last"
              ? "three_quarter_after_floor_then_full_last"
              : this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_positive_prefix"
              ? "full_first_then_three_quarter_while_prefix_positive"
              : this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_nonpositive_prefix"
              ? "full_first_then_three_quarter_while_prefix_nonpositive"
                : this.policy ===
                    "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q" ||
                    this.policy ===
                      "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_no_refill"
                  ? "three_quarter_after_floor"
                  : "production",
      value_probe_candidate_breadth_scale:
        this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_empty_retry" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_after_first" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_before_last" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_positive_prefix" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_nonpositive_prefix" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_no_refill"
          ? SELECTIVE_VALUE_PROBE_BREADTH_SCALE
          : 1,
      catchup_endpoint_winners_suppressed_unstable: 0,
      mature_axis_loss_delta_max: 0,
      regret_opportunities_by_min_axis_loss_delta: emptyRegretOpportunityCounter(),
      repair_incumbent_regret_opportunities_by_min_axis_loss_delta:
        emptyRepairIncumbentRegretOpportunityCounter(),
      repair_incumbent_regret_opportunities_by_min_contact_advance:
        emptyRepairIncumbentMaturityOpportunityCounter(),
      repair_incumbent_axis_loss_delta_max: 0,
      repair_incumbent_max_backtracks_per_attempt:
        this.policy === "selective_axis_regret_catchup_repair_incumbent_once" ? 1 : 0,
      repair_incumbent_attempt_limit_suppressed_watches: 0,
      periodic_contact_interval: SELECTIVE_PERIODIC_CONTACT_INTERVAL,
      periodic_contact_rewind: SELECTIVE_PERIODIC_CONTACT_REWIND,
      periodic_terminal_reserve_factor: SELECTIVE_PERIODIC_TERMINAL_RESERVE_FACTOR,
      periodic_exploration_budget_fraction:
        SELECTIVE_PERIODIC_EXPLORATION_BUDGET_FRACTION,
      periodic_schedule_checks: 0,
      periodic_exact_rewind_opportunities: 0,
      periodic_admitted: 0,
      periodic_alternative_unavailable: 0,
      periodic_execution_ceiling_suppressed: 0,
      periodic_terminal_reserve_suppressed: 0,
      periodic_exploration_allowance_suppressed: 0,
      periodic_probe_frames: 0,
      periodic_probe_nodes_processed: 0,
      periodic_opportunities: [],
      value_min_contact_advance: SELECTIVE_VALUE_MIN_CONTACT_ADVANCE,
      value_density_frame_scale: SELECTIVE_VALUE_DENSITY_FRAME_SCALE,
      value_density_thresholds: [...SELECTIVE_VALUE_DENSITY_THRESHOLDS],
      value_opportunities_by_density: emptyValueOpportunityCounter(),
      value_opportunities: [],
      value_live_density_threshold: SELECTIVE_VALUE_LIVE_DENSITY_THRESHOLD,
      value_live_exploration_budget_fraction:
        valueExplorationBudgetFraction(this.policy),
      value_live_min_gap_progress:
        this.policy === "selective_axis_regret_catchup_value_initial_progress_10" ||
          this.policy === "selective_axis_regret_catchup_value_initial_expire_10" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_stable_priority" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_first_deficit_stop_005" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_first_advantage_handoff" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_empty_retry" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_after_first" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_before_last" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_positive_prefix" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_nonpositive_prefix" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_no_refill" ||
          this.policy === "selective_axis_regret_catchup_value_initial_expire_10_run_proof"
          ? SELECTIVE_VALUE_LIVE_MIN_GAP_PROGRESS
          : 0,
      value_live_progress_suppressed_watches: 0,
      value_live_progress_expired_watches: 0,
      value_live_run_proof_state:
        this.policy === "selective_axis_regret_catchup_value_initial_expire_10_run_proof"
          ? "awaiting_first_tournament"
          : "disabled",
      value_live_run_proof_first_event_index: null,
      value_live_run_proof_first_outcome: null,
      value_live_run_proof_first_reached_target: null,
      value_live_run_proof_sealed_opportunities: 0,
      value_live_crossings: 0,
      value_live_admitted: 0,
      value_live_ranked_out: 0,
      value_live_production_priority: 0,
      value_live_alternative_unavailable: 0,
      value_live_execution_ceiling_suppressed: 0,
      value_live_terminal_reserve_suppressed: 0,
      value_live_exploration_allowance_suppressed: 0,
      value_live_probe_frames: 0,
      value_live_probe_nodes_processed: 0,
      value_live_probe_budget_yields: 0,
      value_live_opportunities: [],
      deferred_value_density_threshold: SELECTIVE_VALUE_LIVE_DENSITY_THRESHOLD,
      deferred_value_min_gap_progress: SELECTIVE_VALUE_LIVE_MIN_GAP_PROGRESS,
      deferred_value_allowance_fractions: [
        ...SELECTIVE_DEFERRED_VALUE_ALLOWANCE_FRACTIONS,
      ],
      deferred_value_map_max_allowance_fraction:
        SELECTIVE_DEFERRED_VALUE_MAP_MAX_ALLOWANCE_FRACTION,
      deferred_value_crossings: 0,
      deferred_value_progress_expired: 0,
      deferred_value_alternative_unavailable_at_collection: 0,
      deferred_value_collected: 0,
      deferred_value_assessed: 0,
      deferred_value_incumbent_path: 0,
      deferred_value_production_consumed: 0,
      deferred_value_alternative_unavailable_at_terminal: 0,
      deferred_value_affordable: 0,
      deferred_value_first_terminal_total_spent_frames: null,
      deferred_value_first_terminal_track_hash: null,
      deferred_value_opportunities: [],
      deferred_value_attempts: [],
      contact_expansions_observed: 0,
      branch_watches_armed: 0,
      branch_watches_by_alternative_count: {},
      mature_watch_checks: 0,
      loss_threshold_crossings: 0,
      deadline_suppressed_crossings: 0,
      execution_ceiling_suppressed_crossings: 0,
      unavailable_alternatives: 0,
      selective_backtracks: 0,
      selective_backtracks_by_signal: emptySignalCounter(),
      selective_backtracks_with_multiple_admissible_rewind_choices: 0,
      admissible_rewind_choice_count_sum: 0,
      admissible_rewind_choice_count_max: 0,
      selective_backtracks_with_additional_sibling_available: 0,
      additional_siblings_available_at_selective_backtrack_sum: 0,
      additional_siblings_available_at_selective_backtrack_max: 0,
      suspended_continuations_resumed: 0,
      catchup_completed: 0,
      catchup_alternative_selected: 0,
      catchup_current_selected: 0,
      catchup_probe_dead_ends: 0,
      catchup_probe_deferred: 0,
      catchup_probe_budget_yields: 0,
      catchup_probe_first_deficit_stops: 0,
      catchup_probe_first_advantage_handoffs: 0,
      catchup_first_advantage_handoffs_selected: 0,
      catchup_execution_ceiling_stops: 0,
      catchup_probe_attempts: 0,
      catchup_probe_target_reaches: 0,
      catchup_probes_with_local_fallback_choice: 0,
      catchup_probes_with_positive_local_fallback_choice: 0,
      catchup_local_fallback_choice_count_sum: 0,
      catchup_positive_local_fallback_choice_count_sum: 0,
      catchup_local_fallback_choice_count_max: 0,
      catchup_additional_probe_attempts: 0,
      catchup_additional_probe_target_reaches: 0,
      catchup_tournaments_with_additional_probe: 0,
      catchup_additional_alternative_selected: 0,
      catchup_probe_nodes_processed: 0,
      catchup_probe_frames: 0,
      route_lease_audit_enabled: this.routeLeaseAuditEnabled,
      route_lease_rollback_enabled: this.routeLeaseRollbackEnabled,
      route_lease_revalidation_enabled: this.routeLeaseRevalidationEnabled,
      route_lease_renewal_audit_enabled: this.routeLeaseRenewalAuditEnabled,
      route_lease_revalidation_lineage_reset_enabled: this.routeLeaseResetLineageEnabled,
      route_lease_audits_started: 0,
      route_lease_audits_selected: 0,
      route_lease_audits_with_loss_crossing: 0,
      route_lease_rollbacks_admitted: 0,
      route_lease_rollbacks_executed: 0,
      route_lease_rollbacks_incumbent_unavailable: 0,
      route_lease_rollbacks_terminal_reserve_suppressed: 0,
      route_lease_revalidations_eligible: 0,
      route_lease_revalidations_admitted: 0,
      route_lease_revalidations_started: 0,
      route_lease_revalidations_incumbent_unavailable: 0,
      route_lease_revalidations_terminal_reserve_suppressed: 0,
      route_lease_revalidations_probe_allowance_suppressed: 0,
      route_lease_revalidations_target_reached: 0,
      route_lease_revalidations_current_selected: 0,
      route_lease_revalidations_incumbent_selected: 0,
      route_lease_revalidations_probe_dead_ends: 0,
      route_lease_revalidations_probe_deferred: 0,
      route_lease_revalidations_probe_budget_yields: 0,
      route_lease_revalidations_execution_ceiling_stops: 0,
      route_lease_revalidation_probe_nodes_processed: 0,
      route_lease_revalidation_probe_frames: 0,
      route_lease_renewal_audits_started: 0,
      route_lease_renewal_audits_with_loss_crossing: 0,
      route_lease_revalidation_lineage_resets: 0,
      route_lease_revalidation_selected_watch_links_cleared: 0,
      route_lease_revalidation_displaced_watch_links_cleared: 0,
      route_lease_revalidation_unique_watch_ids_cleared: 0,
      route_lease_audits: [],
      axis_loss_delta_sum: 0,
      axis_loss_delta_max: 0,
      contact_advance_sum: 0,
      contact_advance_max: 0,
      gap_rewind_sum: 0,
      gap_rewind_max: 0,
      selective_backtracks_by_lane: emptyLaneCounter(),
      events: [],
    };
  }

  observeRoot(node: Node): void {
    if (!this.lineage.has(node)) this.lineage.set(node, null);
  }

  replaceNode(previous: Node, replacement: Node): void {
    this.lineage.set(replacement, this.lineage.get(previous) ?? null);
    const routeLeaseAuditIndex = this.routeLeaseNodes.get(previous);
    if (routeLeaseAuditIndex !== undefined) {
      this.routeLeaseNodes.set(replacement, routeLeaseAuditIndex);
    }
    const eventIndex = this.suspended.get(previous);
    if (eventIndex !== undefined) {
      this.suspended.delete(previous);
      this.suspended.set(replacement, eventIndex);
    }
  }

  /** Freeze the behavior-neutral initial portfolio at the first improving
   * terminal. The callbacks keep generic watch state separate from the
   * compiler's frontier and prefix representations. */
  assessDeferredValueAtFirstTerminal(input: {
    incumbent: Node;
    firstTerminalTotalSpentFrames: number;
    firstTerminalTrackHash: string;
    remainingHardBudgetFrames: number;
    remainingRepairBudgetFrames: number;
    searchPolicyBudgetFrames: number;
    explorationAllowanceFrames: number;
    currentOnIncumbentPath: (current: Node, incumbent: Node) => boolean;
    alternativeAvailable: (alternative: Node) => boolean;
    estimatedSuffixWorkFrames: (alternative: Node) => number;
  }): SelectiveDeferredValueDecision<Node> | null {
    if (
      this.policy !== "selective_axis_regret_catchup_value_deferred_map" &&
      this.policy !== "selective_axis_regret_catchup_value_deferred_initial" &&
      this.policy !== "selective_axis_regret_catchup_value_deferred_pass_only" &&
      this.policy !== "selective_axis_regret_catchup_value_deferred_prefix_gate"
    ) return null;
    if (this.deferredValueSealed) {
      throw new Error("deferred value portfolio was sealed more than once");
    }
    this.deferredValueSealed = true;
    this.stats.deferred_value_first_terminal_total_spent_frames =
      input.firstTerminalTotalSpentFrames;
    this.stats.deferred_value_first_terminal_track_hash = input.firstTerminalTrackHash;
    const ranked: Array<{
      candidate: DeferredValueCandidate<Node>;
      crossing: SelectiveValueOpportunityPoint;
      terminal: SelectiveDeferredValueTerminalAssessment;
    }> = [];
    for (const candidate of this.deferredValueCandidates) {
      const record = this.stats.deferred_value_opportunities[candidate.recordIndex];
      if (record === undefined || record.outcome !== "collected" || record.terminal !== null) {
        throw new Error("deferred value portfolio lost its collection record");
      }
      const onIncumbentPath = input.currentOnIncumbentPath(
        candidate.current,
        input.incumbent,
      );
      const productionConsumed = candidate.watch.used;
      const alternativeAvailable = input.alternativeAvailable(candidate.watch.alternative);
      const estimatedSuffixWork = Math.max(
        1,
        Math.ceil(input.estimatedSuffixWorkFrames(candidate.watch.alternative)),
      );
      const hardRemaining = Math.max(0, Math.floor(input.remainingHardBudgetFrames));
      const repairRemaining = Math.max(0, Math.floor(input.remainingRepairBudgetFrames));
      const explorationAllowance = Math.max(
        0,
        Math.floor(input.explorationAllowanceFrames),
      );
      const localAllowance = Math.min(
        hardRemaining,
        repairRemaining,
        explorationAllowance,
      );
      const reason: SelectiveDeferredValueTerminalAssessment["reason"] =
        !onIncumbentPath
          ? "not_incumbent_path"
          : productionConsumed
            ? "production_consumed"
            : !alternativeAvailable
              ? "alternative_unavailable"
              : estimatedSuffixWork > hardRemaining
                ? "hard_budget"
                : estimatedSuffixWork > repairRemaining
                  ? "repair_budget"
                  : estimatedSuffixWork > explorationAllowance
                    ? "exploration_allowance"
                    : "admitted";
      const terminal: SelectiveDeferredValueTerminalAssessment = {
        first_terminal_total_spent_frames: input.firstTerminalTotalSpentFrames,
        first_terminal_track_hash: input.firstTerminalTrackHash,
        on_incumbent_path: onIncumbentPath,
        production_consumed: productionConsumed,
        alternative_available: alternativeAvailable,
        remaining_hard_budget_frames: hardRemaining,
        remaining_repair_budget_frames: repairRemaining,
        search_policy_budget_frames: Math.max(
          0,
          Math.floor(input.searchPolicyBudgetFrames),
        ),
        exploration_allowance_frames: explorationAllowance,
        local_allowance_frames: localAllowance,
        estimated_suffix_work_frames: estimatedSuffixWork,
        terminal_value_density_per_10k_estimated_frames:
          candidate.axisLossDelta * SELECTIVE_VALUE_DENSITY_FRAME_SCALE /
          estimatedSuffixWork,
        affordable: reason === "admitted",
        reason,
        affordable_rank: null,
      };
      record.terminal = terminal;
      this.stats.deferred_value_assessed++;
      if (onIncumbentPath) this.stats.deferred_value_incumbent_path++;
      if (productionConsumed) this.stats.deferred_value_production_consumed++;
      if (!alternativeAvailable) {
        this.stats.deferred_value_alternative_unavailable_at_terminal++;
      }
      if (terminal.affordable) {
        this.stats.deferred_value_affordable++;
        ranked.push({ candidate, crossing: record.crossing, terminal });
      }
    }
    ranked.sort((left, right) =>
      right.terminal.terminal_value_density_per_10k_estimated_frames -
        left.terminal.terminal_value_density_per_10k_estimated_frames ||
      right.crossing.axis_loss_delta - left.crossing.axis_loss_delta ||
      right.crossing.alternative_gap_index - left.crossing.alternative_gap_index ||
      left.candidate.watch.watchId - right.candidate.watch.watchId
    );
    for (let index = 0; index < ranked.length; index++) {
      ranked[index]!.terminal.affordable_rank = index + 1;
    }
    const winner = ranked[0];
    return winner === undefined
      ? null
      : {
        watchId: winner.candidate.watch.watchId,
        current: winner.candidate.current,
        alternative: winner.candidate.watch.alternative,
        crossing: { ...winner.crossing, budget: { ...winner.crossing.budget } },
        terminal: { ...winner.terminal },
      };
  }

  recordDeferredValueAttempt(attempt: SelectiveDeferredValueAttempt): void {
    if (
      this.policy !== "selective_axis_regret_catchup_value_deferred_initial" &&
      this.policy !== "selective_axis_regret_catchup_value_deferred_pass_only" &&
      this.policy !== "selective_axis_regret_catchup_value_deferred_prefix_gate"
    ) {
      throw new Error("deferred value execution was recorded outside the live policy");
    }
    if (this.stats.deferred_value_attempts.length !== 0) {
      throw new Error("deferred value policy executed more than one suffix attempt");
    }
    if (attempt.affordable_rank !== 1) {
      throw new Error("deferred value execution did not use the rank-one opportunity");
    }
    this.stats.deferred_value_attempts.push({ ...attempt });
  }

  /** Propagate all ancestor watches to every child and arm one new watch only
   * on the ranker's preferred child. The concrete runner-up object is the
   * rewind target; no candidate is regenerated later. */
  observeExpansion(input: {
    parent: Node;
    children: readonly Node[];
    contactExpansion: boolean;
    contactOrdinal: number;
    axisLoss: number;
    /** Whole-prefix axis loss for each child, aligned with `children`. The
     * production compiler supplies this for contact expansions; generic unit
     * harnesses may omit it when branch-value evidence is irrelevant. */
    childAxisLosses?: readonly number[];
  }): void {
    const inherited = this.lineage.get(input.parent) ?? null;
    for (const child of input.children) this.lineage.set(child, inherited);
    const routeLeaseAuditIndex = this.routeLeaseNodes.get(input.parent);
    if (routeLeaseAuditIndex !== undefined &&
      this.stats.route_lease_audits[routeLeaseAuditIndex]?.end_reason === null) {
      for (const child of input.children) {
        this.routeLeaseNodes.set(child, routeLeaseAuditIndex);
      }
    }
    if (!input.contactExpansion) return;
    this.stats.contact_expansions_observed++;
    if (input.children.length < 2) return;
    if (
      input.childAxisLosses !== undefined &&
      (input.childAxisLosses.length !== input.children.length ||
        input.childAxisLosses.some((loss) => !Number.isFinite(loss)))
    ) {
      throw new Error("selective branch child-axis evidence must align and be finite");
    }
    const preferredAxisLoss = input.childAxisLosses?.[0] ?? null;
    const alternativeAxisLoss = input.childAxisLosses?.[1] ?? null;
    if (
      preferredAxisLoss !== null && alternativeAxisLoss !== null &&
      this.gapIndexOf(input.children[0]!) !== this.gapIndexOf(input.children[1]!)
    ) {
      throw new Error("selective branch child-axis evidence must compare equal horizons");
    }

    const watch: AxisRegretWatch<Node> = {
      watchId: this.nextWatchId++,
      alternative: input.children[1]!,
      additionalAlternatives: input.children.slice(2),
      branchContactOrdinal: input.contactOrdinal,
      branchGapIndex: this.gapIndexOf(input.parent),
      baselineAxisLoss: input.axisLoss,
      branchPreferredAxisLoss: preferredAxisLoss,
      branchAlternativeAxisLoss: alternativeAxisLoss,
      branchAlternativeAxisLossGain:
        preferredAxisLoss === null || alternativeAxisLoss === null
          ? null
          : preferredAxisLoss - alternativeAxisLoss,
      used: false,
      signalCrossed: false,
      deadlineSuppressionRecorded: false,
      opportunityCrossedMask: 0,
      opportunityAdmissibleMask: 0,
      repairIncumbentOpportunityCrossedMask: 0,
      repairIncumbentOpportunityAdmissibleMask: 0,
      repairIncumbentMaturityOpportunityCrossedMask: 0,
      repairIncumbentMaturityOpportunityAdmissibleMask: 0,
      repairIncumbentAttemptLimitSuppressionRecorded: false,
      valueOpportunityCrossedMask: 0,
      valueOpportunityAdmissibleMask: 0,
      valueOpportunityRecordIndices: SELECTIVE_VALUE_DENSITY_THRESHOLDS.map(() => null),
      valueLiveCrossed: false,
      valueLiveProgressSuppressionRecorded: false,
      deferredValueCrossed: false,
    };
    this.lineage.set(input.children[0]!, { watch, parent: inherited });
    this.stats.branch_watches_armed++;
    const alternativeCount = input.children.length - 1;
    const alternativeCountKey = String(alternativeCount);
    this.stats.branch_watches_by_alternative_count[alternativeCountKey] =
      (this.stats.branch_watches_by_alternative_count[alternativeCountKey] ?? 0) + 1;
  }

  consider(input: {
    node: Node;
    contactOrdinal: number;
    contactBoundary?: boolean;
    gapProgress?: number;
    axisLoss: number;
    incumbentAxisLoss?: number | null;
    repairAttemptIndex?: number | null;
    executionCeilingReached: boolean;
    totalSpentFrames: number;
    lane: FrontierTraversalLane;
    alternativeAvailable: (node: Node) => boolean;
    alternativeDeadline: (node: Node) => { margin: number; pressured: boolean };
    explorationBudgetAssessment?: (
      alternative: Node,
      fromGapIndex: number,
      explorationProbeFrames: number,
    ) => SelectiveExplorationBudgetAssessment;
    /** Exact authored-axis observation window. Called only when a value
     * opportunity is first materialized; never participates in selection. */
    axisWindow?: (
      fromGapIndex: number,
      throughGapIndex: number,
    ) => { axisCount: number; axisSse: number; axisLoss: number };
  }): SelectiveBacktrackDecision<Node> | null {
    const periodicLaneEnabled =
      (this.policy === "selective_axis_regret_catchup_periodic_initial" &&
        input.lane === "initial") ||
      (this.policy === "selective_axis_regret_catchup_periodic_repair" &&
        input.lane === "repair");
    const periodicScheduled = periodicLaneEnabled &&
      input.contactBoundary === true &&
      input.contactOrdinal > 0 &&
      input.contactOrdinal % SELECTIVE_PERIODIC_CONTACT_INTERVAL === 0;
    if (periodicScheduled) this.stats.periodic_schedule_checks++;
    let periodicCandidate: {
      watch: AxisRegretWatch<Node>;
      contactAdvance: number;
      axisLossDelta: number;
    } | null = null;
    const valueLiveCandidates: Array<{
      watch: AxisRegretWatch<Node>;
      contactAdvance: number;
      axisLossDelta: number;
      density: number;
      gapRewind: number;
      lineageOrder: number;
      deadline: { margin: number; pressured: boolean };
      budget: SelectiveExplorationBudgetAssessment;
      point: SelectiveValueOpportunityPoint;
    }> = [];
    let lineageOrder = 0;

    const recordDecision = (
      watch: AxisRegretWatch<Node>,
      contactAdvance: number,
      axisLossDelta: number,
      triggerSignal: SelectiveBacktrackSignal,
      incumbentAxisLossDelta: number | null,
      repairAttemptIndex: number | null,
      admittedAlternativeDeadline: { margin: number; pressured: boolean },
      admissibleRewindChoices: SelectiveAdmissibleRewindChoice[],
      explorationBudget: SelectiveExplorationBudgetAssessment | null,
      valuePoint: SelectiveValueOpportunityPoint | null,
    ): SelectiveBacktrackDecision<Node> => {
      const fromGapIndex = this.gapIndexOf(input.node);
      this.endRouteLeaseForNode(
        input.node,
        "superseded_by_selective_tournament",
        input.totalSpentFrames,
      );
      const targetGapIndex = this.gapIndexOf(watch.alternative);
      const gapRewind = Math.max(0, fromGapIndex - targetGapIndex);
      watch.used = true;
      const availableAdditionalAlternatives = watch.additionalAlternatives.filter(
        (alternative) => input.alternativeAvailable(alternative),
      );
      const additionalSiblingsAvailable = availableAdditionalAlternatives.length;
      const alternatives = [watch.alternative];
      this.stats.selective_backtracks++;
      this.stats.selective_backtracks_by_signal[triggerSignal]++;
      this.stats.admissible_rewind_choice_count_sum += admissibleRewindChoices.length;
      this.stats.admissible_rewind_choice_count_max = Math.max(
        this.stats.admissible_rewind_choice_count_max,
        admissibleRewindChoices.length,
      );
      if (admissibleRewindChoices.length > 1) {
        this.stats.selective_backtracks_with_multiple_admissible_rewind_choices++;
      }
      if (triggerSignal === "repair_incumbent_regret") {
        this.repairAttemptsWithIncumbentBacktrack.add(repairAttemptIndex!);
      }
      if (additionalSiblingsAvailable > 0) {
        this.stats.selective_backtracks_with_additional_sibling_available++;
      }
      this.stats.additional_siblings_available_at_selective_backtrack_sum +=
        additionalSiblingsAvailable;
      this.stats.additional_siblings_available_at_selective_backtrack_max = Math.max(
        this.stats.additional_siblings_available_at_selective_backtrack_max,
        additionalSiblingsAvailable,
      );
      this.stats.selective_backtracks_by_lane[input.lane]++;
      this.stats.axis_loss_delta_sum += axisLossDelta;
      this.stats.axis_loss_delta_max = Math.max(this.stats.axis_loss_delta_max, axisLossDelta);
      this.stats.contact_advance_sum += contactAdvance;
      this.stats.contact_advance_max = Math.max(this.stats.contact_advance_max, contactAdvance);
      this.stats.gap_rewind_sum += gapRewind;
      this.stats.gap_rewind_max = Math.max(this.stats.gap_rewind_max, gapRewind);
      const eventIndex = this.stats.events.length;
      this.stats.events.push({
        watch_id: watch.watchId,
        lane: input.lane,
        trigger_signal: triggerSignal,
        branch_gap_index: watch.branchGapIndex,
        from_gap_index: fromGapIndex,
        alternative_gap_index: targetGapIndex,
        additional_siblings_available: additionalSiblingsAvailable,
        catchup_alternatives_requested: alternatives.length,
        contact_advance: contactAdvance,
        gap_rewind: gapRewind,
        baseline_axis_loss: watch.baselineAxisLoss,
        trigger_axis_loss: input.axisLoss,
        axis_loss_delta: axisLossDelta,
        branch_preferred_axis_loss: watch.branchPreferredAxisLoss,
        branch_alternative_axis_loss: watch.branchAlternativeAxisLoss,
        branch_alternative_axis_loss_gain: watch.branchAlternativeAxisLossGain,
        current_divergent_suffix_axis_count:
          valuePoint?.current_divergent_suffix_axis_count ?? null,
        current_divergent_suffix_axis_sse:
          valuePoint?.current_divergent_suffix_axis_sse ?? null,
        current_divergent_suffix_axis_loss:
          valuePoint?.current_divergent_suffix_axis_loss ?? null,
        incumbent_axis_loss: input.incumbentAxisLoss ?? null,
        incumbent_axis_loss_delta: incumbentAxisLossDelta,
        repair_attempt_index: repairAttemptIndex,
        periodic_budget: triggerSignal === "periodic_exploration"
          ? explorationBudget
          : null,
        value_budget: triggerSignal === "value_exploration"
          ? explorationBudget
          : null,
        admissible_rewind_choices: admissibleRewindChoices,
        alternative_conservative_deadline_margin: admittedAlternativeDeadline.margin,
        trigger_total_spent_frames: input.totalSpentFrames,
        resumed_total_spent_frames: null,
        first_advantage_handoff_total_spent_frames: null,
        catchup_outcome: null,
        catchup_end_gap_index: null,
        catchup_probe_nodes_processed: 0,
        catchup_probe_frames: 0,
        catchup_axis_loss: null,
        catchup_axis_loss_gain: null,
        catchup_best_alternative_all_checkpoints_positive: null,
        catchup_endpoint_winner_priority_suppressed: false,
        catchup_selected_alternative_ordinal: null,
        catchup_selected_route_ordinal: null,
        catchup_probe_results: [],
        catchup_checkpoints: [],
      });
      this.suspended.set(input.node, eventIndex);
      return {
        alternative: watch.alternative,
        alternatives,
        eventIndex,
        branchGapIndex: watch.branchGapIndex,
        fromGapIndex,
        contactAdvance,
        gapRewind,
        axisLossDelta,
        triggerAxisLoss: input.axisLoss,
        triggerSignal,
        incumbentAxisLoss: input.incumbentAxisLoss ?? null,
        incumbentAxisLossDelta,
        repairAttemptIndex,
        explorationBudget,
      };
    };

    const recordValueLiveOpportunity = (
      watch: AxisRegretWatch<Node>,
      point: SelectiveValueOpportunityPoint,
      outcome: SelectiveValueLiveOpportunity["outcome"],
      affordableRank: number | null,
    ): void => {
      this.stats.value_live_opportunities.push({
        watch_id: watch.watchId,
        outcome,
        affordable_rank: affordableRank,
        point,
      });
      if (outcome === "admitted") this.stats.value_live_admitted++;
      else if (outcome === "ranked_out") this.stats.value_live_ranked_out++;
      else if (outcome === "production_priority") {
        this.stats.value_live_production_priority++;
      } else if (outcome === "progress_expired") {
        this.stats.value_live_progress_expired_watches++;
      } else if (outcome === "run_proof_sealed") {
        this.stats.value_live_run_proof_sealed_opportunities++;
      } else if (outcome === "alternative_unavailable") {
        this.stats.value_live_alternative_unavailable++;
      } else if (outcome === "execution_ceiling") {
        this.stats.value_live_execution_ceiling_suppressed++;
      } else if (outcome === "terminal_reserve") {
        this.stats.value_live_terminal_reserve_suppressed++;
      } else if (outcome === "exploration_allowance") {
        this.stats.value_live_exploration_allowance_suppressed++;
      }
    };

    const flushValueCandidatesForProductionPriority = (): void => {
      for (const candidate of valueLiveCandidates) {
        recordValueLiveOpportunity(
          candidate.watch,
          candidate.point,
          "production_priority",
          null,
        );
      }
      valueLiveCandidates.length = 0;
    };

    let link = this.lineage.get(input.node) ?? null;
    while (link !== null) {
      const watch = link.watch;
      link = link.parent;
      const currentLineageOrder = lineageOrder++;
      if (watch.used) continue;

      const contactAdvance = input.contactOrdinal - watch.branchContactOrdinal;
      if (contactAdvance < SELECTIVE_AXIS_REGRET_MIN_CONTACT_ADVANCE) continue;
      this.stats.mature_watch_checks++;
      const axisLossDelta = input.axisLoss - watch.baselineAxisLoss;
      if (
        periodicScheduled &&
        periodicCandidate === null &&
        contactAdvance === SELECTIVE_PERIODIC_CONTACT_REWIND
      ) {
        periodicCandidate = { watch, contactAdvance, axisLossDelta };
      }
      this.stats.mature_axis_loss_delta_max = Math.max(
        this.stats.mature_axis_loss_delta_max,
        axisLossDelta,
      );

      let alternativeAvailable: boolean | undefined;
      let alternativeDeadline: { margin: number; pressured: boolean } | undefined;
      const readAlternativeAvailable = (): boolean => {
        alternativeAvailable ??= input.alternativeAvailable(watch.alternative);
        return alternativeAvailable;
      };
      const readAlternativeDeadline = (): { margin: number; pressured: boolean } => {
        alternativeDeadline ??= input.alternativeDeadline(watch.alternative);
        return alternativeDeadline;
      };
      const pointAxisEvidence = (): Pick<
        SelectiveValueOpportunityPoint,
        | "branch_preferred_axis_loss"
        | "branch_alternative_axis_loss"
        | "branch_alternative_axis_loss_gain"
        | "current_divergent_suffix_axis_count"
        | "current_divergent_suffix_axis_sse"
        | "current_divergent_suffix_axis_loss"
      > => {
        const suffix = input.axisWindow?.(
          watch.branchGapIndex,
          this.gapIndexOf(input.node),
        ) ?? null;
        if (
          suffix !== null &&
          (!Number.isSafeInteger(suffix.axisCount) || suffix.axisCount < 0 ||
            !Number.isFinite(suffix.axisSse) || suffix.axisSse < 0 ||
            !Number.isFinite(suffix.axisLoss) || suffix.axisLoss < 0)
        ) {
          throw new Error("selective divergent-suffix axis evidence is invalid");
        }
        return {
          branch_preferred_axis_loss: watch.branchPreferredAxisLoss,
          branch_alternative_axis_loss: watch.branchAlternativeAxisLoss,
          branch_alternative_axis_loss_gain: watch.branchAlternativeAxisLossGain,
          current_divergent_suffix_axis_count: suffix?.axisCount ?? null,
          current_divergent_suffix_axis_sse: suffix?.axisSse ?? null,
          current_divergent_suffix_axis_loss: suffix?.axisLoss ?? null,
        };
      };

      if (
        this.policy === "selective_axis_regret_catchup_value_map" &&
        (input.lane === "initial" || input.lane === "repair") &&
        input.contactBoundary === true &&
        contactAdvance >= SELECTIVE_VALUE_MIN_CONTACT_ADVANCE &&
        axisLossDelta > 0
      ) {
        if (input.explorationBudgetAssessment === undefined) {
          throw new Error("value opportunity map requires a budget assessment");
        }
        const fromGapIndex = this.gapIndexOf(input.node);
        const alternativeGapIndex = this.gapIndexOf(watch.alternative);
        const budget = input.explorationBudgetAssessment(
          watch.alternative,
          fromGapIndex,
          0,
        );
        const available = readAlternativeAvailable();
        const density = axisLossDelta * SELECTIVE_VALUE_DENSITY_FRAME_SCALE /
          Math.max(1, budget.estimated_probe_work_frames);
        const point = (): SelectiveValueOpportunityPoint => ({
          lane: input.lane,
          contact_ordinal: input.contactOrdinal,
          from_gap_index: fromGapIndex,
          branch_gap_index: watch.branchGapIndex,
          alternative_gap_index: alternativeGapIndex,
          contact_advance: contactAdvance,
          gap_rewind: Math.max(0, fromGapIndex - alternativeGapIndex),
          baseline_axis_loss: watch.baselineAxisLoss,
          current_axis_loss: input.axisLoss,
          axis_loss_delta: axisLossDelta,
          ...pointAxisEvidence(),
          value_density_per_10k_estimated_frames: density,
          gap_progress: input.gapProgress ?? null,
          total_spent_frames: input.totalSpentFrames,
          alternative_available: available,
          execution_ceiling_reached: input.executionCeilingReached,
          budget: { ...budget },
        });
        for (let i = 0; i < SELECTIVE_VALUE_DENSITY_THRESHOLDS.length; i++) {
          const threshold = SELECTIVE_VALUE_DENSITY_THRESHOLDS[i]!;
          if (density < threshold) continue;
          const bit = 1 << i;
          const counter = this.stats.value_opportunities_by_density[threshold.toFixed(3)]!;
          if ((watch.valueOpportunityCrossedMask & bit) === 0) {
            watch.valueOpportunityCrossedMask |= bit;
            counter.crossed_watches++;
            watch.valueOpportunityRecordIndices[i] = this.stats.value_opportunities.length;
            this.stats.value_opportunities.push({
              watch_id: watch.watchId,
              threshold,
              crossing: point(),
              first_admission: null,
            });
          }
          if (
            (watch.valueOpportunityAdmissibleMask & bit) === 0 &&
            available &&
            !input.executionCeilingReached &&
            budget.admitted
          ) {
            watch.valueOpportunityAdmissibleMask |= bit;
            counter.admissible_watches++;
            const recordIndex = watch.valueOpportunityRecordIndices[i];
            if (recordIndex === null || recordIndex === undefined) {
              throw new Error("value opportunity admission lost its crossing record");
            }
            this.stats.value_opportunities[recordIndex]!.first_admission = point();
          }
        }
      }

      if (
        (this.policy === "selective_axis_regret_catchup_value_deferred_map" ||
          this.policy === "selective_axis_regret_catchup_value_deferred_initial" ||
          this.policy === "selective_axis_regret_catchup_value_deferred_pass_only" ||
          this.policy === "selective_axis_regret_catchup_value_deferred_prefix_gate") &&
        input.lane === "initial" &&
        input.contactBoundary === true &&
        contactAdvance >= SELECTIVE_VALUE_MIN_CONTACT_ADVANCE &&
        axisLossDelta > 0 &&
        !watch.deferredValueCrossed &&
        !this.deferredValueSealed
      ) {
        if (input.explorationBudgetAssessment === undefined) {
          throw new Error("deferred value map requires a budget assessment");
        }
        const fromGapIndex = this.gapIndexOf(input.node);
        const alternativeGapIndex = this.gapIndexOf(watch.alternative);
        const budget = input.explorationBudgetAssessment(
          watch.alternative,
          fromGapIndex,
          0,
        );
        const density = axisLossDelta * SELECTIVE_VALUE_DENSITY_FRAME_SCALE /
          Math.max(1, budget.estimated_probe_work_frames);
        if (density >= SELECTIVE_VALUE_LIVE_DENSITY_THRESHOLD) {
          watch.deferredValueCrossed = true;
          this.stats.deferred_value_crossings++;
          const available = readAlternativeAvailable();
          const crossing: SelectiveValueOpportunityPoint = {
            lane: input.lane,
            contact_ordinal: input.contactOrdinal,
            from_gap_index: fromGapIndex,
            branch_gap_index: watch.branchGapIndex,
            alternative_gap_index: alternativeGapIndex,
            contact_advance: contactAdvance,
            gap_rewind: Math.max(0, fromGapIndex - alternativeGapIndex),
            baseline_axis_loss: watch.baselineAxisLoss,
            current_axis_loss: input.axisLoss,
            axis_loss_delta: axisLossDelta,
            ...pointAxisEvidence(),
            value_density_per_10k_estimated_frames: density,
            gap_progress: input.gapProgress ?? null,
            total_spent_frames: input.totalSpentFrames,
            alternative_available: available,
            execution_ceiling_reached: input.executionCeilingReached,
            budget: { ...budget },
          };
          const gapProgress = input.gapProgress ?? 0;
          const outcome: SelectiveDeferredValueOpportunity["outcome"] =
            gapProgress < SELECTIVE_VALUE_LIVE_MIN_GAP_PROGRESS
              ? "progress_expired"
              : !available
                ? "alternative_unavailable_at_collection"
                : "collected";
          const recordIndex = this.stats.deferred_value_opportunities.length;
          this.stats.deferred_value_opportunities.push({
            watch_id: watch.watchId,
            outcome,
            crossing,
            terminal: null,
          });
          if (outcome === "progress_expired") {
            this.stats.deferred_value_progress_expired++;
          } else if (outcome === "alternative_unavailable_at_collection") {
            this.stats.deferred_value_alternative_unavailable_at_collection++;
          } else {
            this.stats.deferred_value_collected++;
            this.deferredValueCandidates.push({
              watch,
              current: input.node,
              recordIndex,
              axisLossDelta,
            });
          }
        }
      }

      if (
        (this.policy === "selective_axis_regret_catchup_value_initial" ||
          this.policy === "selective_axis_regret_catchup_value_initial_progress_10" ||
          this.policy === "selective_axis_regret_catchup_value_initial_expire_10" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_stable_priority" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_first_deficit_stop_005" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_first_advantage_handoff" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_empty_retry" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_after_first" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_before_last" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_positive_prefix" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_nonpositive_prefix" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_no_refill" ||
          this.policy ===
            "selective_axis_regret_catchup_value_initial_expire_10_run_proof") &&
        input.lane === "initial" &&
        input.contactBoundary === true &&
        contactAdvance >= SELECTIVE_VALUE_MIN_CONTACT_ADVANCE &&
        axisLossDelta > 0 &&
        !watch.valueLiveCrossed
      ) {
        if (input.explorationBudgetAssessment === undefined) {
          throw new Error("value-ranked selective backtracking requires a budget assessment");
        }
        const fromGapIndex = this.gapIndexOf(input.node);
        const alternativeGapIndex = this.gapIndexOf(watch.alternative);
        const budget = input.explorationBudgetAssessment(
          watch.alternative,
          fromGapIndex,
          this.stats.value_live_probe_frames,
        );
        const density = axisLossDelta * SELECTIVE_VALUE_DENSITY_FRAME_SCALE /
          Math.max(1, budget.estimated_probe_work_frames);
        const makePoint = (): SelectiveValueOpportunityPoint => ({
          lane: input.lane,
          contact_ordinal: input.contactOrdinal,
          from_gap_index: fromGapIndex,
          branch_gap_index: watch.branchGapIndex,
          alternative_gap_index: alternativeGapIndex,
          contact_advance: contactAdvance,
          gap_rewind: Math.max(0, fromGapIndex - alternativeGapIndex),
          baseline_axis_loss: watch.baselineAxisLoss,
          current_axis_loss: input.axisLoss,
          axis_loss_delta: axisLossDelta,
          ...pointAxisEvidence(),
          value_density_per_10k_estimated_frames: density,
          gap_progress: input.gapProgress ?? null,
          total_spent_frames: input.totalSpentFrames,
          alternative_available: readAlternativeAvailable(),
          execution_ceiling_reached: input.executionCeilingReached,
          budget: { ...budget },
        });
        if (density >= SELECTIVE_VALUE_LIVE_DENSITY_THRESHOLD) {
          const minimumProgress = this.stats.value_live_min_gap_progress;
          const gapProgress = input.gapProgress ?? 0;
          if (gapProgress < minimumProgress) {
            if (
              this.policy === "selective_axis_regret_catchup_value_initial_expire_10" ||
              this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_stable_priority" ||
              this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_first_deficit_stop_005" ||
              this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_first_advantage_handoff" ||
              this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q" ||
              this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_empty_retry" ||
              this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_after_first" ||
              this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_before_last" ||
              this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_positive_prefix" ||
              this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_nonpositive_prefix" ||
              this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_no_refill" ||
              this.policy ===
                "selective_axis_regret_catchup_value_initial_expire_10_run_proof"
            ) {
              watch.valueLiveCrossed = true;
              this.stats.value_live_crossings++;
              recordValueLiveOpportunity(watch, makePoint(), "progress_expired", null);
            } else if (!watch.valueLiveProgressSuppressionRecorded) {
              watch.valueLiveProgressSuppressionRecorded = true;
              this.stats.value_live_progress_suppressed_watches++;
            }
          } else {
            watch.valueLiveCrossed = true;
            this.stats.value_live_crossings++;
            const point = makePoint();
            const available = point.alternative_available;
            if (!available) {
              recordValueLiveOpportunity(
                watch,
                point,
                "alternative_unavailable",
                null,
              );
            } else if (input.executionCeilingReached) {
              recordValueLiveOpportunity(watch, point, "execution_ceiling", null);
            } else if (!budget.admitted) {
              recordValueLiveOpportunity(watch, point, budget.reason, null);
            } else if (
              this.policy ===
                  "selective_axis_regret_catchup_value_initial_expire_10_run_proof" &&
              this.stats.value_live_run_proof_state ===
                "sealed_after_failed_first_tournament"
            ) {
              recordValueLiveOpportunity(watch, point, "run_proof_sealed", null);
            } else {
              valueLiveCandidates.push({
                watch,
                contactAdvance,
                axisLossDelta,
                density,
                gapRewind: point.gap_rewind,
                lineageOrder: currentLineageOrder,
                deadline: readAlternativeDeadline(),
                budget,
                point,
              });
            }
          }
        }
      }

      const incumbentAxisLossDelta =
        input.lane === "repair" &&
        input.incumbentAxisLoss !== null &&
        input.incumbentAxisLoss !== undefined &&
        Number.isFinite(input.incumbentAxisLoss)
          ? input.axisLoss - input.incumbentAxisLoss
          : null;
      if (incumbentAxisLossDelta !== null) {
        this.stats.repair_incumbent_axis_loss_delta_max = Math.max(
          this.stats.repair_incumbent_axis_loss_delta_max,
          incumbentAxisLossDelta,
        );
        let newlyEligibleRepairMask = 0;
        for (let i = 0; i < REPAIR_INCUMBENT_REGRET_OPPORTUNITY_THRESHOLDS.length; i++) {
          const threshold = REPAIR_INCUMBENT_REGRET_OPPORTUNITY_THRESHOLDS[i]!;
          if (!(incumbentAxisLossDelta > threshold)) continue;
          const bit = 1 << i;
          const counter =
            this.stats.repair_incumbent_regret_opportunities_by_min_axis_loss_delta[
              threshold.toFixed(2)
            ]!;
          if ((watch.repairIncumbentOpportunityCrossedMask & bit) === 0) {
            watch.repairIncumbentOpportunityCrossedMask |= bit;
            counter.crossed_watches++;
          }
          if ((watch.repairIncumbentOpportunityAdmissibleMask & bit) === 0) {
            newlyEligibleRepairMask |= bit;
          }
        }
        if (
          newlyEligibleRepairMask !== 0 &&
          !input.executionCeilingReached &&
          readAlternativeAvailable() &&
          !readAlternativeDeadline().pressured
        ) {
          for (let i = 0; i < REPAIR_INCUMBENT_REGRET_OPPORTUNITY_THRESHOLDS.length; i++) {
            const bit = 1 << i;
            if ((newlyEligibleRepairMask & bit) === 0) continue;
            watch.repairIncumbentOpportunityAdmissibleMask |= bit;
            const threshold = REPAIR_INCUMBENT_REGRET_OPPORTUNITY_THRESHOLDS[i]!;
            this.stats.repair_incumbent_regret_opportunities_by_min_axis_loss_delta[
              threshold.toFixed(2)
            ]!.admissible_watches++;
          }
        }
        let newlyEligibleMaturityMask = 0;
        if (incumbentAxisLossDelta > SELECTIVE_REPAIR_INCUMBENT_MIN_LOSS_DELTA) {
          for (let i = 0; i < REPAIR_INCUMBENT_REGRET_OPPORTUNITY_CONTACT_ADVANCES.length; i++) {
            const advance = REPAIR_INCUMBENT_REGRET_OPPORTUNITY_CONTACT_ADVANCES[i]!;
            if (contactAdvance < advance) continue;
            const bit = 1 << i;
            const counter =
              this.stats.repair_incumbent_regret_opportunities_by_min_contact_advance[
                String(advance)
              ]!;
            if ((watch.repairIncumbentMaturityOpportunityCrossedMask & bit) === 0) {
              watch.repairIncumbentMaturityOpportunityCrossedMask |= bit;
              counter.crossed_watches++;
            }
            if ((watch.repairIncumbentMaturityOpportunityAdmissibleMask & bit) === 0) {
              newlyEligibleMaturityMask |= bit;
            }
          }
        }
        if (
          newlyEligibleMaturityMask !== 0 &&
          !input.executionCeilingReached &&
          readAlternativeAvailable() &&
          !readAlternativeDeadline().pressured
        ) {
          for (let i = 0; i < REPAIR_INCUMBENT_REGRET_OPPORTUNITY_CONTACT_ADVANCES.length; i++) {
            const bit = 1 << i;
            if ((newlyEligibleMaturityMask & bit) === 0) continue;
            watch.repairIncumbentMaturityOpportunityAdmissibleMask |= bit;
            const advance = REPAIR_INCUMBENT_REGRET_OPPORTUNITY_CONTACT_ADVANCES[i]!;
            this.stats.repair_incumbent_regret_opportunities_by_min_contact_advance[
              String(advance)
            ]!.admissible_watches++;
          }
        }
      }

      let newlyEligibleMask = 0;
      for (let i = 0; i < SELECTIVE_AXIS_REGRET_OPPORTUNITY_THRESHOLDS.length; i++) {
        const threshold = SELECTIVE_AXIS_REGRET_OPPORTUNITY_THRESHOLDS[i]!;
        if (axisLossDelta < threshold) continue;
        const bit = 1 << i;
        const counter = this.stats.regret_opportunities_by_min_axis_loss_delta[
          threshold.toFixed(2)
        ]!;
        if ((watch.opportunityCrossedMask & bit) === 0) {
          watch.opportunityCrossedMask |= bit;
          counter.crossed_watches++;
        }
        if ((watch.opportunityAdmissibleMask & bit) === 0) newlyEligibleMask |= bit;
      }
      if (
        newlyEligibleMask !== 0 &&
        !input.executionCeilingReached &&
        readAlternativeAvailable() &&
        !readAlternativeDeadline().pressured
      ) {
        for (let i = 0; i < SELECTIVE_AXIS_REGRET_OPPORTUNITY_THRESHOLDS.length; i++) {
          const bit = 1 << i;
          if ((newlyEligibleMask & bit) === 0) continue;
          watch.opportunityAdmissibleMask |= bit;
          const threshold = SELECTIVE_AXIS_REGRET_OPPORTUNITY_THRESHOLDS[i]!;
          this.stats.regret_opportunities_by_min_axis_loss_delta[
            threshold.toFixed(2)
          ]!.admissible_watches++;
        }
      }
      const branchRegretTriggered = axisLossDelta >= SELECTIVE_AXIS_REGRET_MIN_LOSS_DELTA;
      if (branchRegretTriggered && !watch.signalCrossed) {
        watch.signalCrossed = true;
        this.stats.loss_threshold_crossings++;
      }
      const repairIncumbentRegretTriggered =
        this.policy === "selective_axis_regret_catchup_repair_incumbent_once" &&
        incumbentAxisLossDelta !== null &&
        incumbentAxisLossDelta > SELECTIVE_REPAIR_INCUMBENT_MIN_LOSS_DELTA;
      if (!branchRegretTriggered && !repairIncumbentRegretTriggered) continue;
      const triggerSignal: SelectiveBacktrackSignal = branchRegretTriggered
        ? "branch_regret"
        : "repair_incumbent_regret";
      const repairAttemptIndex = input.lane === "repair"
        ? input.repairAttemptIndex ?? null
        : null;
      if (triggerSignal === "repair_incumbent_regret") {
        if (!Number.isSafeInteger(repairAttemptIndex) || repairAttemptIndex! < 0) {
          throw new Error("repair-incumbent catch-up requires a repair attempt index");
        }
        if (this.repairAttemptsWithIncumbentBacktrack.has(repairAttemptIndex!)) {
          if (!watch.repairIncumbentAttemptLimitSuppressionRecorded) {
            watch.repairIncumbentAttemptLimitSuppressionRecorded = true;
            this.stats.repair_incumbent_attempt_limit_suppressed_watches++;
          }
          continue;
        }
      }

      const fromGapIndex = this.gapIndexOf(input.node);
      const targetGapIndex = this.gapIndexOf(watch.alternative);
      const gapRewind = Math.max(0, fromGapIndex - targetGapIndex);
      if (!readAlternativeAvailable()) {
        watch.used = true;
        this.stats.unavailable_alternatives++;
        continue;
      }
      if (input.executionCeilingReached) {
        this.stats.execution_ceiling_suppressed_crossings++;
        continue;
      }
      const admittedAlternativeDeadline = readAlternativeDeadline();
      if (admittedAlternativeDeadline.pressured) {
        if (!watch.deadlineSuppressionRecorded) {
          watch.deadlineSuppressionRecorded = true;
          this.stats.deadline_suppressed_crossings++;
        }
        continue;
      }
      const admissibleRewindChoices: SelectiveAdmissibleRewindChoice[] = [];
      let choiceLink = this.lineage.get(input.node) ?? null;
      while (choiceLink !== null) {
        const choiceWatch = choiceLink.watch;
        choiceLink = choiceLink.parent;
        if (choiceWatch.used) continue;
        const choiceContactAdvance = input.contactOrdinal - choiceWatch.branchContactOrdinal;
        if (choiceContactAdvance < SELECTIVE_AXIS_REGRET_MIN_CONTACT_ADVANCE) continue;
        const choiceAxisLossDelta = input.axisLoss - choiceWatch.baselineAxisLoss;
        const choiceTriggered = triggerSignal === "branch_regret"
          ? choiceAxisLossDelta >= SELECTIVE_AXIS_REGRET_MIN_LOSS_DELTA
          : repairIncumbentRegretTriggered;
        if (!choiceTriggered || !input.alternativeAvailable(choiceWatch.alternative)) continue;
        const choiceDeadline = input.alternativeDeadline(choiceWatch.alternative);
        if (choiceDeadline.pressured) continue;
        const choiceTargetGapIndex = this.gapIndexOf(choiceWatch.alternative);
        admissibleRewindChoices.push({
          branch_gap_index: choiceWatch.branchGapIndex,
          alternative_gap_index: choiceTargetGapIndex,
          contact_advance: choiceContactAdvance,
          gap_rewind: Math.max(0, fromGapIndex - choiceTargetGapIndex),
          axis_loss_delta: choiceAxisLossDelta,
          conservative_deadline_margin: choiceDeadline.margin,
        });
      }
      const selectedChoice = admissibleRewindChoices[0];
      if (
        selectedChoice === undefined ||
        selectedChoice.branch_gap_index !== watch.branchGapIndex ||
        selectedChoice.alternative_gap_index !== targetGapIndex
      ) {
        throw new Error("selective backtrack choice map lost the selected causal sibling");
      }
      flushValueCandidatesForProductionPriority();
      return recordDecision(
        watch,
        contactAdvance,
        axisLossDelta,
        triggerSignal,
        incumbentAxisLossDelta,
        repairAttemptIndex,
        admittedAlternativeDeadline,
        admissibleRewindChoices,
        null,
        null,
      );
    }

    if (
      (this.policy === "selective_axis_regret_catchup_value_initial" ||
        this.policy === "selective_axis_regret_catchup_value_initial_progress_10" ||
        this.policy === "selective_axis_regret_catchup_value_initial_expire_10" ||
        this.policy ===
          "selective_axis_regret_catchup_value_initial_expire_10_stable_priority" ||
        this.policy ===
          "selective_axis_regret_catchup_value_initial_expire_10_first_deficit_stop_005" ||
        this.policy ===
          "selective_axis_regret_catchup_value_initial_expire_10_first_advantage_handoff" ||
        this.policy ===
          "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q" ||
        this.policy ===
          "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_empty_retry" ||
        this.policy ===
          "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_after_first" ||
        this.policy ===
          "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_before_last" ||
        this.policy ===
          "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_positive_prefix" ||
        this.policy ===
          "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_nonpositive_prefix" ||
        this.policy ===
          "selective_axis_regret_catchup_value_initial_expire_10_probe_breadth_3q_no_refill" ||
        this.policy === "selective_axis_regret_catchup_value_initial_expire_10_run_proof") &&
      valueLiveCandidates.length > 0
    ) {
      valueLiveCandidates.sort((left, right) =>
        right.density - left.density ||
        right.axisLossDelta - left.axisLossDelta ||
        left.gapRewind - right.gapRewind ||
        left.lineageOrder - right.lineageOrder
      );
      for (let i = 0; i < valueLiveCandidates.length; i++) {
        const candidate = valueLiveCandidates[i]!;
        recordValueLiveOpportunity(
          candidate.watch,
          candidate.point,
          i === 0 ? "admitted" : "ranked_out",
          i + 1,
        );
      }
      const winner = valueLiveCandidates[0]!;
      const fromGapIndex = this.gapIndexOf(input.node);
      const targetGapIndex = this.gapIndexOf(winner.watch.alternative);
      return recordDecision(
        winner.watch,
        winner.contactAdvance,
        winner.axisLossDelta,
        "value_exploration",
        null,
        null,
        winner.deadline,
        [{
          branch_gap_index: winner.watch.branchGapIndex,
          alternative_gap_index: targetGapIndex,
          contact_advance: winner.contactAdvance,
          gap_rewind: Math.max(0, fromGapIndex - targetGapIndex),
          axis_loss_delta: winner.axisLossDelta,
          conservative_deadline_margin: winner.deadline.margin,
        }],
        winner.budget,
        winner.point,
      );
    }

    if (periodicCandidate === null) return null;
    this.stats.periodic_exact_rewind_opportunities++;
    const { watch, contactAdvance, axisLossDelta } = periodicCandidate;
    const fromGapIndex = this.gapIndexOf(input.node);
    const targetGapIndex = this.gapIndexOf(watch.alternative);
    const recordPeriodicOpportunity = (
      outcome: SelectivePeriodicOpportunity["outcome"],
      deadlineMargin: number | null,
      budget: SelectiveExplorationBudgetAssessment | null,
    ): void => {
      this.stats.periodic_opportunities.push({
        lane: input.lane,
        contact_ordinal: input.contactOrdinal,
        from_gap_index: fromGapIndex,
        branch_gap_index: watch.branchGapIndex,
        alternative_gap_index: targetGapIndex,
        outcome,
        conservative_deadline_margin: deadlineMargin,
        budget,
      });
    };
    if (!input.alternativeAvailable(watch.alternative)) {
      watch.used = true;
      this.stats.periodic_alternative_unavailable++;
      recordPeriodicOpportunity("alternative_unavailable", null, null);
      return null;
    }
    if (input.executionCeilingReached) {
      this.stats.periodic_execution_ceiling_suppressed++;
      recordPeriodicOpportunity("execution_ceiling", null, null);
      return null;
    }
    const admittedAlternativeDeadline = input.alternativeDeadline(watch.alternative);
    if (input.explorationBudgetAssessment === undefined) {
      throw new Error("periodic selective backtracking requires a budget assessment");
    }
    const periodicBudget = input.explorationBudgetAssessment(
      watch.alternative,
      fromGapIndex,
      this.stats.periodic_probe_frames,
    );
    if (!periodicBudget.admitted) {
      if (periodicBudget.reason === "terminal_reserve") {
        this.stats.periodic_terminal_reserve_suppressed++;
      } else {
        this.stats.periodic_exploration_allowance_suppressed++;
      }
      recordPeriodicOpportunity(
        periodicBudget.reason,
        admittedAlternativeDeadline.margin,
        periodicBudget,
      );
      return null;
    }
    this.stats.periodic_admitted++;
    recordPeriodicOpportunity("admitted", admittedAlternativeDeadline.margin, periodicBudget);
    const repairAttemptIndex = input.lane === "repair"
      ? input.repairAttemptIndex ?? null
      : null;
    return recordDecision(
      watch,
      contactAdvance,
      axisLossDelta,
      "periodic_exploration",
      input.lane === "repair" && input.incumbentAxisLoss !== null &&
          input.incumbentAxisLoss !== undefined && Number.isFinite(input.incumbentAxisLoss)
        ? input.axisLoss - input.incumbentAxisLoss
        : null,
      repairAttemptIndex,
      admittedAlternativeDeadline,
      [{
        branch_gap_index: watch.branchGapIndex,
        alternative_gap_index: targetGapIndex,
        contact_advance: contactAdvance,
        gap_rewind: Math.max(0, fromGapIndex - targetGapIndex),
        axis_loss_delta: axisLossDelta,
        conservative_deadline_margin: admittedAlternativeDeadline.margin,
      }],
      periodicBudget,
      null,
    );
  }

  markSuspended(node: Node): void {
    if (!this.suspended.has(node)) {
      throw new Error("selective backtrack suspended a node without a causal event");
    }
  }

  /** Start a behavior-neutral audit after a completed equal-depth tournament
   * selects an alternative. The scheduler remains the sole owner of both
   * nodes; this method only binds their object identities to telemetry. */
  markSelectedRouteLease(
    selected: Node,
    displacedIncumbent: Node,
    decision: SelectiveBacktrackDecision<Node>,
    input: {
      selectedRouteOrdinal: number;
      selectedAlternativeOrdinal: number;
      selectedTakeover: SelectiveRouteLeaseAxisWindow;
      displacedIncumbentTakeover: SelectiveRouteLeaseAxisWindow;
    },
  ): void {
    if (!this.routeLeaseAuditEnabled) return;
    const event = this.stats.events[decision.eventIndex];
    if (
      event?.catchup_outcome !== "alternative_selected" ||
      decision.triggerSignal !== "value_exploration" ||
      event.catchup_selected_route_ordinal !== input.selectedRouteOrdinal ||
      event.catchup_selected_alternative_ordinal !== input.selectedAlternativeOrdinal ||
      this.gapIndexOf(selected) !== decision.fromGapIndex ||
      this.gapIndexOf(displacedIncumbent) !== decision.fromGapIndex ||
      this.routeLeaseNodes.has(selected)
    ) throw new Error("selected-route lease audit has no unique equal-depth tournament");
    validateRouteLeaseAxisWindow(input.selectedTakeover, "selected takeover");
    validateRouteLeaseAxisWindow(
      input.displacedIncumbentTakeover,
      "displaced-incumbent takeover",
    );
    if (
      input.selectedTakeover.axis_count !== input.displacedIncumbentTakeover.axis_count ||
      !(input.displacedIncumbentTakeover.axis_loss > input.selectedTakeover.axis_loss)
    ) throw new Error("selected-route lease audit takeover is not a like-for-like winner");
    const auditIndex = this.stats.route_lease_audits.length;
    this.stats.route_lease_audits.push({
      origin: "initial_tournament",
      parent_audit_index: null,
      event_index: decision.eventIndex,
      takeover_gap_index: decision.fromGapIndex,
      selected_route_ordinal: input.selectedRouteOrdinal,
      selected_alternative_ordinal: input.selectedAlternativeOrdinal,
      selected_takeover: { ...input.selectedTakeover },
      displaced_incumbent_takeover: { ...input.displacedIncumbentTakeover },
      takeover_axis_loss_gain:
        input.displacedIncumbentTakeover.axis_loss - input.selectedTakeover.axis_loss,
      selected_total_spent_frames: null,
      selections_observed: 0,
      deepest_gap_index: decision.fromGapIndex,
      first_loss_crossing: null,
      rollback_disposition: null,
      rollback_total_spent_frames: null,
      revalidation_disposition: null,
      revalidation: null,
      lineage_reset: null,
      checkpoints: [],
      end_reason: null,
      end_total_spent_frames: null,
    });
    this.routeLeaseNodes.set(selected, auditIndex);
    this.routeLeaseIncumbents.set(auditIndex, displacedIncumbent);
    this.routeLeaseDisplacedNodes.set(displacedIncumbent, auditIndex);
    this.stats.route_lease_audits_started++;
  }

  /** Start a behavior-neutral lease after a completed same-horizon
   * revalidation. Both endpoints are unprocessed at this horizon; the
   * scheduler owns their order and this method only follows object identity. */
  markRenewedRouteLease(
    selected: Node,
    displaced: Node,
    parentAuditIndex: number,
    totalSpentFrames: number,
    selectedTakeover: SelectiveRouteLeaseAxisWindow,
    displacedTakeover: SelectiveRouteLeaseAxisWindow,
  ): void {
    if (!this.routeLeaseRenewalAuditEnabled) return;
    const parent = this.stats.route_lease_audits[parentAuditIndex];
    if (
      parent === undefined || parent.revalidation === null ||
      parent.end_total_spent_frames !== totalSpentFrames ||
      (parent.revalidation.outcome !== "current_selected" &&
        parent.revalidation.outcome !== "incumbent_selected") ||
      this.gapIndexOf(selected) !== parent.revalidation.target_gap_index ||
      this.gapIndexOf(displaced) !== parent.revalidation.target_gap_index ||
      (this.routeLeaseNodes.get(selected) !== undefined &&
        this.routeLeaseNodes.get(selected) !== parentAuditIndex)
    ) throw new Error("renewed route lease has no completed parent revalidation");
    validateRouteLeaseAxisWindow(selectedTakeover, "renewed selected takeover");
    validateRouteLeaseAxisWindow(displacedTakeover, "renewed displaced takeover");
    if (
      selectedTakeover.axis_count !== displacedTakeover.axis_count ||
      selectedTakeover.axis_loss > displacedTakeover.axis_loss
    ) throw new Error("renewed route lease did not bind its measured winner");
    const auditIndex = this.stats.route_lease_audits.length;
    this.stats.route_lease_audits.push({
      origin: "revalidation_renewal",
      parent_audit_index: parentAuditIndex,
      event_index: parent.event_index,
      takeover_gap_index: this.gapIndexOf(selected),
      selected_route_ordinal: null,
      selected_alternative_ordinal: null,
      selected_takeover: { ...selectedTakeover },
      displaced_incumbent_takeover: { ...displacedTakeover },
      takeover_axis_loss_gain: displacedTakeover.axis_loss - selectedTakeover.axis_loss,
      selected_total_spent_frames: null,
      selections_observed: 0,
      deepest_gap_index: this.gapIndexOf(selected),
      first_loss_crossing: null,
      rollback_disposition: null,
      rollback_total_spent_frames: null,
      revalidation_disposition: null,
      revalidation: null,
      lineage_reset: null,
      checkpoints: [],
      end_reason: null,
      end_total_spent_frames: null,
    });
    this.routeLeaseNodes.set(selected, auditIndex);
    this.routeLeaseIncumbents.set(auditIndex, displaced);
    this.routeLeaseDisplacedNodes.set(displaced, auditIndex);
    this.stats.route_lease_audits_started++;
    this.stats.route_lease_renewal_audits_started++;
  }

  /** Return the private node context required to observe, but never drive, a
   * selected-route lease. Null keeps the production hot path unchanged. */
  routeLeaseAuditContext(node: Node): {
    takeoverGapIndex: number;
    displacedIncumbent: Node;
  } | null {
    if (!this.routeLeaseAuditEnabled) return null;
    const auditIndex = this.routeLeaseNodes.get(node);
    if (auditIndex === undefined) return null;
    const audit = this.stats.route_lease_audits[auditIndex];
    const displacedIncumbent = this.routeLeaseIncumbents.get(auditIndex);
    if (audit === undefined || audit.end_reason !== null || displacedIncumbent === undefined) {
      return null;
    }
    return { takeoverGapIndex: audit.takeover_gap_index, displacedIncumbent };
  }

  claimRouteLeaseRollback(node: Node, totalSpentFrames: number): {
    auditIndex: number;
    displacedIncumbent: Node;
  } | null {
    const auditIndex = this.pendingRouteLeaseRollbacks.get(node);
    if (auditIndex === undefined) return null;
    this.pendingRouteLeaseRollbacks.delete(node);
    const audit = this.stats.route_lease_audits[auditIndex];
    const displacedIncumbent = this.routeLeaseIncumbents.get(auditIndex);
    if (
      !this.routeLeaseRollbackEnabled || audit === undefined ||
      displacedIncumbent === undefined || audit.end_reason !== null ||
      audit.rollback_disposition !== "admitted" ||
      audit.rollback_total_spent_frames !== null
    ) throw new Error("selected-route rollback lost its admitted lease");
    audit.rollback_disposition = "executed";
    audit.rollback_total_spent_frames = totalSpentFrames;
    this.stats.route_lease_rollbacks_executed++;
    return { auditIndex, displacedIncumbent };
  }

  claimRouteLeaseRevalidation(
    node: Node,
    totalSpentFrames: number,
    assess: (incumbent: Node, targetGapIndex: number) => {
      probeAllowanceFrames: number;
      estimatedProbeWorkFrames: number;
      terminalReserveFrames: number;
      executionRemainingFrames: number;
      estimatedNextNodeFrames: number;
    },
  ): {
    auditIndex: number;
    displacedIncumbent: Node;
    targetGapIndex: number;
    probeAllowanceFrames: number;
    estimatedProbeWorkFrames: number;
    terminalReserveFrames: number;
    executionRemainingFrames: number;
    estimatedNextNodeFrames: number;
  } | null {
    const auditIndex = this.pendingRouteLeaseRevalidations.get(node);
    if (auditIndex === undefined) return null;
    this.pendingRouteLeaseRevalidations.delete(node);
    const audit = this.stats.route_lease_audits[auditIndex];
    const displacedIncumbent = this.routeLeaseIncumbents.get(auditIndex);
    if (
      !this.routeLeaseRevalidationEnabled || audit === undefined ||
      displacedIncumbent === undefined || audit.end_reason !== null ||
      audit.revalidation_disposition !== "eligible" || audit.revalidation !== null ||
      this.gapIndexOf(node) <= this.gapIndexOf(displacedIncumbent)
    ) throw new Error("selected-route revalidation lost its admitted lease");
    const targetGapIndex = this.gapIndexOf(node);
    const assessment = assess(displacedIncumbent, targetGapIndex);
    if (
      !Number.isFinite(assessment.probeAllowanceFrames) ||
      !Number.isFinite(assessment.estimatedProbeWorkFrames) ||
      !Number.isFinite(assessment.terminalReserveFrames) ||
      !Number.isFinite(assessment.executionRemainingFrames) ||
      !Number.isFinite(assessment.estimatedNextNodeFrames) ||
      Object.values(assessment).some((value) => value < 0)
    ) throw new Error("route-lease revalidation has an invalid budget assessment");
    if (assessment.estimatedNextNodeFrames > assessment.probeAllowanceFrames) {
      audit.revalidation_disposition = "probe_allowance";
      this.stats.route_lease_revalidations_probe_allowance_suppressed++;
      return null;
    }
    audit.revalidation_disposition = "started";
    this.stats.route_lease_revalidations_admitted++;
    this.stats.route_lease_revalidations_started++;
    return {
      auditIndex,
      displacedIncumbent,
      targetGapIndex,
      ...assessment,
    };
  }

  consumeRouteLeaseRevalidationIncumbent(
    node: Node,
    auditIndex: number,
    totalSpentFrames: number,
  ): boolean {
    const audit = this.stats.route_lease_audits[auditIndex];
    const eventIndex = this.suspended.get(node);
    if (
      !this.routeLeaseRevalidationEnabled || audit === undefined ||
      audit.end_reason !== null || audit.revalidation_disposition !== "started" ||
      this.routeLeaseIncumbents.get(auditIndex) !== node ||
      eventIndex !== audit.event_index
    ) throw new Error("route-lease revalidation lost its suspended incumbent");
    this.suspended.delete(node);
    this.stats.events[eventIndex]!.resumed_total_spent_frames = totalSpentFrames;
    this.stats.suspended_continuations_resumed++;
    return true;
  }

  finishRouteLeaseRevalidation(
    auditIndex: number,
    input: NonNullable<SelectiveRouteLeaseAudit["revalidation"]>,
  ): void {
    const audit = this.stats.route_lease_audits[auditIndex];
    if (
      !this.routeLeaseRevalidationEnabled || audit === undefined ||
      audit.end_reason !== null || audit.revalidation_disposition !== "started" ||
      audit.revalidation !== null || input.target_gap_index <= audit.takeover_gap_index ||
      input.end_total_spent_frames < input.start_total_spent_frames ||
      input.probe_frames !== input.end_total_spent_frames - input.start_total_spent_frames ||
      input.probe_nodes_processed < 0 || input.probe_allowance_frames < 0 ||
      input.estimated_probe_work_frames < 0 || input.terminal_reserve_frames < 0 ||
      input.execution_remaining_frames < 0 ||
      input.preflight_estimated_next_node_frames < 0
    ) throw new Error("invalid route-lease revalidation result");
    const reachedTarget = input.outcome === "current_selected" ||
      input.outcome === "incumbent_selected";
    const currentLoss = input.current_axis_loss;
    const incumbentLoss = input.incumbent_axis_loss;
    const hasEndpointWindows = input.current_axis_count !== null &&
      input.incumbent_axis_count !== null && input.current_axis_sse !== null &&
      input.incumbent_axis_sse !== null;
    if (
      reachedTarget !==
        (currentLoss !== null && incumbentLoss !== null) ||
      reachedTarget !== hasEndpointWindows ||
      (reachedTarget && input.current_axis_count !== input.incumbent_axis_count) ||
      (reachedTarget &&
        (!(input.current_axis_count! > 0) || !(input.current_axis_sse! >= 0) ||
          !(input.incumbent_axis_sse! >= 0))) ||
      (input.outcome === "current_selected" &&
        !(currentLoss! <= incumbentLoss!)) ||
      (input.outcome === "incumbent_selected" &&
        !(incumbentLoss! < currentLoss!))
    ) throw new Error("route-lease revalidation has inconsistent endpoint ranking");
    audit.revalidation = { ...input };
    this.stats.route_lease_revalidation_probe_nodes_processed += input.probe_nodes_processed;
    this.stats.route_lease_revalidation_probe_frames += input.probe_frames;
    if (reachedTarget) this.stats.route_lease_revalidations_target_reached++;
    if (input.outcome === "current_selected") {
      this.stats.route_lease_revalidations_current_selected++;
    } else if (input.outcome === "incumbent_selected") {
      this.stats.route_lease_revalidations_incumbent_selected++;
    } else if (input.outcome === "probe_dead_end") {
      this.stats.route_lease_revalidations_probe_dead_ends++;
    } else if (input.outcome === "probe_deferred") {
      this.stats.route_lease_revalidations_probe_deferred++;
    } else if (input.outcome === "probe_budget_yield") {
      this.stats.route_lease_revalidations_probe_budget_yields++;
    } else {
      this.stats.route_lease_revalidations_execution_ceiling_stops++;
    }
    this.endRouteLease(
      auditIndex,
      input.outcome === "current_selected"
        ? "revalidation_current_selected"
        : input.outcome === "incumbent_selected"
          ? "revalidation_incumbent_selected"
          : "revalidation_probe_stopped",
      input.end_total_spent_frames,
    );
  }

  /** A same-horizon measurement supersedes every causal watch inherited from
   * before that endpoint. Clearing only the two measured endpoint links keeps
   * concrete frontier alternatives and lets later expansions arm fresh
   * watches normally. */
  resetLineageAfterRouteLeaseRevalidation(
    selected: Node,
    displaced: Node,
    parentAuditIndex: number,
    totalSpentFrames: number,
  ): void {
    if (!this.routeLeaseResetLineageEnabled) return;
    const parent = this.stats.route_lease_audits[parentAuditIndex];
    if (
      parent === undefined || parent.revalidation === null ||
      parent.end_total_spent_frames !== totalSpentFrames ||
      parent.lineage_reset !== null ||
      this.gapIndexOf(selected) !== parent.revalidation.target_gap_index ||
      this.gapIndexOf(displaced) !== parent.revalidation.target_gap_index
    ) throw new Error("route-lease lineage reset has no completed revalidation");
    const inheritedWatchIds = (node: Node): number[] => {
      const result: number[] = [];
      const seen = new Set<number>();
      let link = this.lineage.get(node) ?? null;
      while (link !== null) {
        if (seen.has(link.watch.watchId)) {
          throw new Error("route-lease lineage reset found a causal-watch cycle");
        }
        seen.add(link.watch.watchId);
        result.push(link.watch.watchId);
        link = link.parent;
      }
      return result;
    };
    const selectedWatchIds = inheritedWatchIds(selected);
    const displacedWatchIds = inheritedWatchIds(displaced);
    const uniqueWatchIds = new Set([...selectedWatchIds, ...displacedWatchIds]);
    this.lineage.set(selected, null);
    this.lineage.set(displaced, null);
    parent.lineage_reset = {
      total_spent_frames: totalSpentFrames,
      selected_watch_links_cleared: selectedWatchIds.length,
      displaced_watch_links_cleared: displacedWatchIds.length,
      unique_watch_ids_cleared: uniqueWatchIds.size,
    };
    this.stats.route_lease_revalidation_lineage_resets++;
    this.stats.route_lease_revalidation_selected_watch_links_cleared +=
      selectedWatchIds.length;
    this.stats.route_lease_revalidation_displaced_watch_links_cleared +=
      displacedWatchIds.length;
    this.stats.route_lease_revalidation_unique_watch_ids_cleared += uniqueWatchIds.size;
  }

  observeRouteLeaseTerminal(node: Node, totalSpentFrames: number): void {
    this.endRouteLeaseForNode(node, "terminal", totalSpentFrames);
  }

  /** Bind a partial alternative handed back to ordinary DFS to its causal
   * event. Its next selection is recorded separately from incumbent resume. */
  markFirstAdvantageHandoff(
    node: Node,
    decision: SelectiveBacktrackDecision<Node>,
  ): void {
    const event = this.stats.events[decision.eventIndex];
    if (
      event?.catchup_outcome !== "probe_first_advantage_handoff" ||
      event.first_advantage_handoff_total_spent_frames !== null ||
      this.firstAdvantageHandoffs.has(node)
    ) throw new Error("first-checkpoint advantage handoff has no unique causal event");
    this.firstAdvantageHandoffs.set(node, decision.eventIndex);
  }

  /** Record a pure, like-for-like observation while the alternative catches
   * up. This does not decide or mutate traversal. It lets offline studies ask
   * which bounded stopping rules would have saved work before we put any such
   * rule into the compiler. */
  recordCatchupCheckpoint(
    decision: SelectiveBacktrackDecision<Node>,
    routeOrdinal: number,
    routeKind: SelectiveCatchupProbeResult["route_kind"],
    alternativeOrdinal: number,
    checkpoint: Omit<
      SelectiveCatchupCheckpoint,
      "route_ordinal" | "route_kind" | "alternative_ordinal"
    >,
  ): void {
    const event = this.stats.events[decision.eventIndex];
    if (event === undefined || event.catchup_outcome !== null) {
      throw new Error("selective catch-up checkpoint has no live causal event");
    }
    const previous = event.catchup_checkpoints.filter(
      (candidate) => candidate.route_ordinal === routeOrdinal,
    ).at(-1);
    if (
      checkpoint.gap_index <= (previous?.gap_index ?? decision.branchGapIndex) ||
      checkpoint.gap_index > decision.fromGapIndex ||
      checkpoint.probe_nodes_processed < (previous?.probe_nodes_processed ?? 0) ||
      checkpoint.probe_frames < (previous?.probe_frames ?? 0)
    ) {
      throw new Error("selective catch-up checkpoints must advance monotonically to the target");
    }
    event.catchup_checkpoints.push({
      ...checkpoint,
      route_ordinal: routeOrdinal,
      route_kind: routeKind,
      alternative_ordinal: alternativeOrdinal,
    });
  }

  finishCatchup(
    decision: SelectiveBacktrackDecision<Node>,
    input: {
      outcome: SelectiveCatchupOutcome;
      selectedAlternativeOrdinal: number | null;
      selectedRouteOrdinal: number | null;
      probes: readonly SelectiveCatchupProbeResult[];
      catchupAxisLoss: number | null;
      bestAlternativeAllCheckpointsPositive?: boolean | null;
      endpointWinnerPrioritySuppressed?: boolean;
    },
  ): void {
    const event = this.stats.events[decision.eventIndex];
    if (event === undefined || event.catchup_outcome !== null) {
      throw new Error("selective catch-up completion has no live causal event");
    }
    if (input.probes.length === 0) {
      throw new Error("selective catch-up completion has no probe result");
    }
    const probeNodesProcessed = input.probes.reduce(
      (sum, probe) => sum + probe.probe_nodes_processed,
      0,
    );
    const probeFrames = input.probes.reduce((sum, probe) => sum + probe.probe_frames, 0);
    event.catchup_outcome = input.outcome;
    event.catchup_end_gap_index = Math.max(...input.probes.map((probe) => probe.end_gap_index));
    event.catchup_probe_nodes_processed = probeNodesProcessed;
    event.catchup_probe_frames = probeFrames;
    event.catchup_axis_loss = input.catchupAxisLoss;
    event.catchup_axis_loss_gain = input.catchupAxisLoss === null
      ? null
      : decision.triggerAxisLoss - input.catchupAxisLoss;
    event.catchup_best_alternative_all_checkpoints_positive =
      input.bestAlternativeAllCheckpointsPositive ?? null;
    event.catchup_endpoint_winner_priority_suppressed =
      input.endpointWinnerPrioritySuppressed ?? false;
    if (event.catchup_endpoint_winner_priority_suppressed) {
      if (
        this.stats.catchup_priority_rule !== "all_checkpoints_positive" ||
        decision.triggerSignal !== "value_exploration" ||
        input.outcome !== "current_selected" ||
        input.catchupAxisLoss === null ||
        !(decision.triggerAxisLoss > input.catchupAxisLoss) ||
        input.bestAlternativeAllCheckpointsPositive !== false
      ) throw new Error("invalid unstable endpoint-winner priority suppression");
      this.stats.catchup_endpoint_winners_suppressed_unstable++;
    }
    event.catchup_selected_alternative_ordinal = input.selectedAlternativeOrdinal;
    event.catchup_selected_route_ordinal = input.selectedRouteOrdinal;
    event.catchup_probe_results = input.probes.map((probe) => ({
      ...probe,
      local_fallback_choices: probe.local_fallback_choices.map((choice) => ({ ...choice })),
    }));
    this.stats.catchup_probe_nodes_processed += probeNodesProcessed;
    this.stats.catchup_probe_frames += probeFrames;
    if (decision.triggerSignal === "periodic_exploration") {
      this.stats.periodic_probe_nodes_processed += probeNodesProcessed;
      this.stats.periodic_probe_frames += probeFrames;
    } else if (decision.triggerSignal === "value_exploration") {
      this.stats.value_live_probe_nodes_processed += probeNodesProcessed;
      this.stats.value_live_probe_frames += probeFrames;
      if (
        this.policy ===
          "selective_axis_regret_catchup_value_initial_expire_10_run_proof" &&
        this.stats.value_live_run_proof_state === "awaiting_first_tournament"
      ) {
        const reachedTarget = input.probes.some((probe) => probe.outcome === "reached_target");
        this.stats.value_live_run_proof_first_event_index = decision.eventIndex;
        this.stats.value_live_run_proof_first_outcome = input.outcome;
        this.stats.value_live_run_proof_first_reached_target = reachedTarget;
        this.stats.value_live_run_proof_state = reachedTarget
          ? "first_tournament_reached_target"
          : "sealed_after_failed_first_tournament";
      }
    }
    this.stats.catchup_probe_attempts += input.probes.length;
    this.stats.catchup_probe_target_reaches += input.probes.filter(
      (probe) => probe.outcome === "reached_target",
    ).length;
    for (const probe of input.probes) {
      const choiceCount = probe.local_fallback_choices.length;
      const positiveChoiceCount = probe.local_fallback_choices.filter(
        (choice) => choice.current_relative_axis_loss_gain > 0,
      ).length;
      this.stats.catchup_local_fallback_choice_count_sum += choiceCount;
      this.stats.catchup_positive_local_fallback_choice_count_sum += positiveChoiceCount;
      this.stats.catchup_local_fallback_choice_count_max = Math.max(
        this.stats.catchup_local_fallback_choice_count_max,
        choiceCount,
      );
      if (choiceCount > 0) this.stats.catchup_probes_with_local_fallback_choice++;
      if (positiveChoiceCount > 0) {
        this.stats.catchup_probes_with_positive_local_fallback_choice++;
      }
    }
    this.stats.catchup_additional_probe_attempts += input.probes.filter(
      (probe) => probe.route_kind === "causal_alternative" && probe.alternative_ordinal > 1,
    ).length;
    this.stats.catchup_additional_probe_target_reaches += input.probes.filter(
      (probe) =>
        probe.route_kind === "causal_alternative" &&
        probe.alternative_ordinal > 1 &&
        probe.outcome === "reached_target",
    ).length;
    if (input.probes.length > 1) this.stats.catchup_tournaments_with_additional_probe++;
    if ((input.selectedAlternativeOrdinal ?? 0) > 1) {
      this.stats.catchup_additional_alternative_selected++;
    }
    this.stats.catchup_probe_dead_ends += input.probes.filter(
      (probe) => probe.outcome === "probe_dead_end",
    ).length;
    this.stats.catchup_probe_deferred += input.probes.filter(
      (probe) => probe.outcome === "probe_deferred",
    ).length;
    const budgetYields = input.probes.filter(
      (probe) => probe.outcome === "probe_budget_yield",
    ).length;
    this.stats.catchup_probe_budget_yields += budgetYields;
    if (decision.triggerSignal === "value_exploration") {
      this.stats.value_live_probe_budget_yields += budgetYields;
    }
    const firstDeficitStops = input.probes.filter(
      (probe) => probe.outcome === "probe_first_deficit_stop",
    ).length;
    if (firstDeficitStops > 0) {
      const finalCheckpoint = event.catchup_checkpoints.at(-1);
      if (
        this.policy !==
          "selective_axis_regret_catchup_value_initial_expire_10_first_deficit_stop_005" ||
        decision.triggerSignal !== "value_exploration" ||
        input.outcome !== "probe_first_deficit_stop" ||
        firstDeficitStops !== 1 ||
        input.selectedAlternativeOrdinal !== null ||
        input.selectedRouteOrdinal !== null ||
        input.catchupAxisLoss !== null ||
        input.probes.length !== 1 ||
        finalCheckpoint === undefined ||
        event.catchup_checkpoints.length !== 1 ||
        finalCheckpoint.gap_index >= decision.fromGapIndex ||
        input.probes[0]!.end_gap_index !== finalCheckpoint.gap_index ||
        !(finalCheckpoint.alternative_axis_loss_gain <=
          -SELECTIVE_VALUE_FIRST_CHECKPOINT_DEFICIT_STOP)
      ) throw new Error("invalid first-checkpoint material-deficit probe stop");
      this.stats.catchup_probe_first_deficit_stops++;
    } else if (input.outcome === "probe_first_deficit_stop") {
      throw new Error("first-checkpoint deficit outcome has no stopped probe");
    }
    const firstAdvantageHandoffs = input.probes.filter(
      (probe) => probe.outcome === "probe_first_advantage_handoff",
    ).length;
    if (firstAdvantageHandoffs > 0) {
      const finalCheckpoint = event.catchup_checkpoints.at(-1);
      const probe = input.probes[0];
      if (
        this.policy !==
          "selective_axis_regret_catchup_value_initial_expire_10_first_advantage_handoff" ||
        decision.triggerSignal !== "value_exploration" ||
        input.outcome !== "probe_first_advantage_handoff" ||
        firstAdvantageHandoffs !== 1 ||
        input.selectedAlternativeOrdinal !== 1 ||
        input.selectedRouteOrdinal !== 1 ||
        input.catchupAxisLoss !== null ||
        input.probes.length !== 1 ||
        probe === undefined ||
        finalCheckpoint === undefined ||
        event.catchup_checkpoints.length !== 1 ||
        finalCheckpoint.gap_index >= decision.fromGapIndex ||
        probe.end_gap_index !== finalCheckpoint.gap_index ||
        probe.axis_loss !== finalCheckpoint.alternative_axis_loss ||
        !(finalCheckpoint.alternative_axis_loss_gain > 0)
      ) throw new Error("invalid first-checkpoint advantage handoff");
      this.stats.catchup_probe_first_advantage_handoffs++;
    } else if (input.outcome === "probe_first_advantage_handoff") {
      throw new Error("first-checkpoint advantage outcome has no handed-off probe");
    }
    this.stats.catchup_execution_ceiling_stops += input.probes.filter(
      (probe) => probe.outcome === "execution_ceiling",
    ).length;
    if (input.outcome === "alternative_selected") {
      this.stats.catchup_completed++;
      this.stats.catchup_alternative_selected++;
    } else if (input.outcome === "current_selected") {
      this.stats.catchup_completed++;
      this.stats.catchup_current_selected++;
    }
  }

  observeSelected(
    node: Node,
    totalSpentFrames: number,
    routeLease?: {
      wholePrefix: SelectiveRouteLeaseAxisWindow;
      divergentSuffix: SelectiveRouteLeaseAxisWindow;
      displacedIncumbentAvailable: boolean;
      displacedIncumbentConservativeDeadlineMargin: number;
      displacedIncumbentAffordableWithReserve: boolean;
    },
  ): boolean {
    const routeLeaseAuditIndex = this.routeLeaseNodes.get(node);
    if (routeLeaseAuditIndex !== undefined) {
      const audit = this.stats.route_lease_audits[routeLeaseAuditIndex];
      if (audit !== undefined && audit.end_reason === null) {
        if (routeLease === undefined) {
          throw new Error("active selected-route lease lost its axis evidence");
        }
        validateRouteLeaseAxisWindow(routeLease.wholePrefix, "route checkpoint prefix");
        validateRouteLeaseAxisWindow(routeLease.divergentSuffix, "route checkpoint suffix");
        if (!Number.isFinite(routeLease.displacedIncumbentConservativeDeadlineMargin)) {
          throw new Error("route checkpoint has a non-finite incumbent deadline margin");
        }
        if (audit.selected_total_spent_frames === null) {
          audit.selected_total_spent_frames = totalSpentFrames;
          this.stats.route_lease_audits_selected++;
        }
        audit.selections_observed++;
        const gapIndex = this.gapIndexOf(node);
        audit.deepest_gap_index = Math.max(audit.deepest_gap_index, gapIndex);
        if (gapIndex > audit.takeover_gap_index) {
          if (
            routeLease.wholePrefix.axis_count !==
              audit.selected_takeover.axis_count + routeLease.divergentSuffix.axis_count ||
            !approximatelyEqual(
              routeLease.wholePrefix.axis_sse,
              audit.selected_takeover.axis_sse + routeLease.divergentSuffix.axis_sse,
            )
          ) throw new Error("route checkpoint prefix/suffix evidence is not additive");
          const checkpoint: SelectiveRouteLeaseCheckpoint = {
            selection_ordinal: audit.selections_observed,
            gap_index: gapIndex,
            total_spent_frames: totalSpentFrames,
            whole_prefix: { ...routeLease.wholePrefix },
            divergent_suffix: { ...routeLease.divergentSuffix },
            loss_excess_over_displaced_incumbent:
              routeLease.wholePrefix.axis_loss -
              audit.displaced_incumbent_takeover.axis_loss,
            displaced_incumbent_available: routeLease.displacedIncumbentAvailable,
            displaced_incumbent_conservative_deadline_margin:
              routeLease.displacedIncumbentConservativeDeadlineMargin,
            displaced_incumbent_affordable_with_reserve:
              routeLease.displacedIncumbentAffordableWithReserve,
          };
          audit.checkpoints.push(checkpoint);
          if (
            audit.first_loss_crossing === null &&
            checkpoint.loss_excess_over_displaced_incumbent > 0
          ) {
            audit.first_loss_crossing = { ...checkpoint };
            this.stats.route_lease_audits_with_loss_crossing++;
            if (audit.origin === "revalidation_renewal") {
              this.stats.route_lease_renewal_audits_with_loss_crossing++;
            } else if (this.routeLeaseRevalidationEnabled) {
              if (!checkpoint.displaced_incumbent_available) {
                audit.revalidation_disposition = "displaced_incumbent_unavailable";
                this.stats.route_lease_revalidations_incumbent_unavailable++;
              } else if (!checkpoint.displaced_incumbent_affordable_with_reserve) {
                audit.revalidation_disposition = "terminal_reserve";
                this.stats.route_lease_revalidations_terminal_reserve_suppressed++;
              } else {
                audit.revalidation_disposition = "eligible";
                this.pendingRouteLeaseRevalidations.set(node, routeLeaseAuditIndex);
                this.stats.route_lease_revalidations_eligible++;
              }
            } else if (!this.routeLeaseRollbackEnabled) {
              audit.rollback_disposition = "audit_only";
            } else if (!checkpoint.displaced_incumbent_available) {
              audit.rollback_disposition = "displaced_incumbent_unavailable";
              this.stats.route_lease_rollbacks_incumbent_unavailable++;
            } else if (!checkpoint.displaced_incumbent_affordable_with_reserve) {
              audit.rollback_disposition = "terminal_reserve";
              this.stats.route_lease_rollbacks_terminal_reserve_suppressed++;
            } else {
              audit.rollback_disposition = "admitted";
              this.pendingRouteLeaseRollbacks.set(node, routeLeaseAuditIndex);
              this.stats.route_lease_rollbacks_admitted++;
            }
          }
        }
      }
    } else if (routeLease !== undefined) {
      throw new Error("selected-route axis evidence has no active lease");
    }
    const displacedAuditIndex = this.routeLeaseDisplacedNodes.get(node);
    if (displacedAuditIndex !== undefined) {
      const displacedAudit = this.stats.route_lease_audits[displacedAuditIndex];
      if (displacedAudit !== undefined && displacedAudit.end_reason === null) {
        this.endRouteLease(
          displacedAuditIndex,
          displacedAudit.origin === "revalidation_renewal"
            ? "displaced_route_selected"
            : "displaced_incumbent_resumed",
          totalSpentFrames,
        );
      }
    }
    const handoffEventIndex = this.firstAdvantageHandoffs.get(node);
    if (handoffEventIndex !== undefined) {
      this.firstAdvantageHandoffs.delete(node);
      const handoffEvent = this.stats.events[handoffEventIndex];
      if (
        handoffEvent === undefined ||
        handoffEvent.catchup_outcome !== "probe_first_advantage_handoff" ||
        handoffEvent.first_advantage_handoff_total_spent_frames !== null
      ) throw new Error("first-checkpoint advantage handoff selection lost attribution");
      handoffEvent.first_advantage_handoff_total_spent_frames = totalSpentFrames;
      this.stats.catchup_first_advantage_handoffs_selected++;
    }
    const eventIndex = this.suspended.get(node);
    if (eventIndex === undefined) return false;
    this.suspended.delete(node);
    this.stats.events[eventIndex]!.resumed_total_spent_frames = totalSpentFrames;
    const resumedAuditIndex = this.stats.route_lease_audits.findIndex(
      (audit) => audit.event_index === eventIndex && audit.end_reason === null,
    );
    if (resumedAuditIndex >= 0) {
      this.endRouteLease(
        resumedAuditIndex,
        "displaced_incumbent_resumed",
        totalSpentFrames,
      );
    }
    this.stats.suspended_continuations_resumed++;
    return true;
  }

  private endRouteLeaseForNode(
    node: Node,
    reason: Exclude<SelectiveRouteLeaseAudit["end_reason"], null>,
    totalSpentFrames: number,
  ): void {
    const auditIndex = this.routeLeaseNodes.get(node);
    if (auditIndex === undefined) return;
    this.endRouteLease(auditIndex, reason, totalSpentFrames);
  }

  private endRouteLease(
    auditIndex: number,
    reason: Exclude<SelectiveRouteLeaseAudit["end_reason"], null>,
    totalSpentFrames: number,
  ): void {
    const audit = this.stats.route_lease_audits[auditIndex];
    if (audit === undefined || audit.end_reason !== null) return;
    audit.end_reason = reason;
    audit.end_total_spent_frames = totalSpentFrames;
    const displaced = this.routeLeaseIncumbents.get(auditIndex);
    if (displaced !== undefined) this.routeLeaseDisplacedNodes.delete(displaced);
    this.routeLeaseIncumbents.delete(auditIndex);
  }

  snapshot(): SelectiveBacktrackingStats {
    return {
      ...this.stats,
      branch_watches_by_alternative_count: {
        ...this.stats.branch_watches_by_alternative_count,
      },
      selective_backtracks_by_lane: { ...this.stats.selective_backtracks_by_lane },
      regret_opportunities_by_min_axis_loss_delta: Object.fromEntries(
        Object.entries(this.stats.regret_opportunities_by_min_axis_loss_delta).map(
          ([threshold, counts]) => [threshold, { ...counts }],
        ),
      ),
      repair_incumbent_regret_opportunities_by_min_axis_loss_delta: Object.fromEntries(
        Object.entries(
          this.stats.repair_incumbent_regret_opportunities_by_min_axis_loss_delta,
        ).map(([threshold, counts]) => [threshold, { ...counts }]),
      ),
      repair_incumbent_regret_opportunities_by_min_contact_advance: Object.fromEntries(
        Object.entries(
          this.stats.repair_incumbent_regret_opportunities_by_min_contact_advance,
        ).map(([advance, counts]) => [advance, { ...counts }]),
      ),
      periodic_opportunities: this.stats.periodic_opportunities.map((opportunity) => ({
        ...opportunity,
        budget: opportunity.budget === null ? null : { ...opportunity.budget },
      })),
      value_density_thresholds: [...this.stats.value_density_thresholds],
      value_opportunities_by_density: Object.fromEntries(
        Object.entries(this.stats.value_opportunities_by_density).map(
          ([threshold, counts]) => [threshold, { ...counts }],
        ),
      ),
      value_opportunities: this.stats.value_opportunities.map((opportunity) => ({
        ...opportunity,
        crossing: {
          ...opportunity.crossing,
          budget: { ...opportunity.crossing.budget },
        },
        first_admission: opportunity.first_admission === null
          ? null
          : {
            ...opportunity.first_admission,
            budget: { ...opportunity.first_admission.budget },
          },
      })),
      value_live_opportunities: this.stats.value_live_opportunities.map((opportunity) => ({
        ...opportunity,
        point: {
          ...opportunity.point,
          budget: { ...opportunity.point.budget },
        },
      })),
      deferred_value_opportunities: this.stats.deferred_value_opportunities.map(
        (opportunity) => ({
          ...opportunity,
          crossing: {
            ...opportunity.crossing,
            budget: { ...opportunity.crossing.budget },
          },
          terminal: opportunity.terminal === null ? null : { ...opportunity.terminal },
        }),
      ),
      deferred_value_attempts: this.stats.deferred_value_attempts.map((attempt) => ({
        ...attempt,
        atomic_node_frames: [...attempt.atomic_node_frames],
        progress_checkpoints: attempt.progress_checkpoints.map((checkpoint) => ({
          ...checkpoint,
          whole_prefix: { ...checkpoint.whole_prefix },
          divergent_suffix: checkpoint.divergent_suffix === null
            ? null
            : { ...checkpoint.divergent_suffix },
          latest_comparable_contact: checkpoint.latest_comparable_contact === null
            ? null
            : { ...checkpoint.latest_comparable_contact },
          divergent_suffix_axis_sse_by_axis: Object.fromEntries(
            Object.entries(checkpoint.divergent_suffix_axis_sse_by_axis).map(
              ([axis, comparison]) => [axis, { ...comparison }],
            ),
          ),
        })),
        pass_frontier_gate: attempt.pass_frontier_gate === null
          ? null
          : {
            ...attempt.pass_frontier_gate,
            checkpoint: attempt.pass_frontier_gate.checkpoint === null
              ? null
              : { ...attempt.pass_frontier_gate.checkpoint },
          },
        prefix_gate: attempt.prefix_gate === null
          ? null
          : {
            ...attempt.prefix_gate,
            checkpoint: attempt.prefix_gate.checkpoint === null
              ? null
              : {
                ...attempt.prefix_gate.checkpoint,
                divergent_suffix: {
                  ...attempt.prefix_gate.checkpoint.divergent_suffix,
                },
              },
          },
      })),
      route_lease_audits: this.stats.route_lease_audits.map((audit) => ({
        ...audit,
        selected_takeover: { ...audit.selected_takeover },
        displaced_incumbent_takeover: { ...audit.displaced_incumbent_takeover },
        first_loss_crossing: audit.first_loss_crossing === null
          ? null
          : {
            ...audit.first_loss_crossing,
            whole_prefix: { ...audit.first_loss_crossing.whole_prefix },
            divergent_suffix: { ...audit.first_loss_crossing.divergent_suffix },
          },
        revalidation: audit.revalidation === null
          ? null
          : { ...audit.revalidation },
        lineage_reset: audit.lineage_reset === null
          ? null
          : { ...audit.lineage_reset },
        checkpoints: audit.checkpoints.map((checkpoint) => ({
          ...checkpoint,
          whole_prefix: { ...checkpoint.whole_prefix },
          divergent_suffix: { ...checkpoint.divergent_suffix },
        })),
      })),
      events: this.stats.events.map((event) => ({
        ...event,
        periodic_budget: event.periodic_budget === null
          ? null
          : { ...event.periodic_budget },
        value_budget: event.value_budget === null
          ? null
          : { ...event.value_budget },
        admissible_rewind_choices: event.admissible_rewind_choices.map((choice) => ({
          ...choice,
        })),
        catchup_probe_results: event.catchup_probe_results.map((probe) => ({
          ...probe,
          atomic_node_frames: [...probe.atomic_node_frames],
          local_fallback_choices: probe.local_fallback_choices.map((choice) => ({ ...choice })),
        })),
        catchup_checkpoints: event.catchup_checkpoints.map((checkpoint) => ({ ...checkpoint })),
      })),
    };
  }
}
