Compiler experiments for the Arc 825 campaign. These are research alternatives.
For an experiment, check out its base commit, apply changes.patch, then copy the
untracked tree into that checkout. Immutable panel options and results are in
arc-825-research.json; large data and intermediate source snapshots stay local.
The deployed compiler is maintained separately on codex/arc-825.
