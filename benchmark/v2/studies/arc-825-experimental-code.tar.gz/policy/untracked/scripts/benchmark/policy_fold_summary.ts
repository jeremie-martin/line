import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {summarizeDevelopmentBudget} from '../v0/benchmark_v2/evaluator.ts';
const root='/home/wyss/line/generated/benchmark-v2/arc-825';
const rows=[];
for(let fold=0;fold<5;fold++){
 const path=root+'/control-policy-fold-'+fold;
 const plan=JSON.parse(readFileSync(path+'/plan.json','utf8'));
 for(const sourceId of plan.sourceIds){const r=JSON.parse(readFileSync(path+'/'+sourceId+'.json','utf8'));rows.push({sourceId,budget:750000,seedSlot:0,actualSeed:r.seed,score:r.score});}
}
const suite=JSON.parse(readFileSync('benchmark/v2/compat/suite-manifest.json','utf8'));
const summary={researchOnly:true,note:'Five complete-parent-held-out models, not one deployed compiler or canonical result.',summary:summarizeDevelopmentBudget(rows,750000,suite)};
const b=JSON.stringify(summary)+'\n';writeFileSync(root+'/control-policy-held-family-summary.json',b);writeFileSync(root+'/control-policy-held-family-summary.json.sha256',createHash('sha256').update(b).digest('hex')+'\n');
console.log(summary.summary.score,summary.summary.validRuns);
