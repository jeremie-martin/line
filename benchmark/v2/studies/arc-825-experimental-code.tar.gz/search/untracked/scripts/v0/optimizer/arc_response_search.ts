/** Experimental measured-response reuse within one fixed physical prefix. */
import {arcResponseStep} from './arc_response.ts';
import type {ArcMotionControl} from './arc_geometry.ts';
type Point={c:ArcMotionControl;residuals:number[];cost:number};
type Input={keys:(keyof ArcMotionControl)[];scale:Record<string,number>;allowance:number;damping:number;
  mode:'broyden'|'regression';value:(c:ArcMotionControl,key:keyof ArcMotionControl)=>number;
  best:()=>Point;observations:()=>Point[];evaluate:(c:ArcMotionControl)=>Point|null;retain:()=>void};
const dot=(a:number[],b:number[])=>a.reduce((s,x,i)=>s+x*b[i],0);
function regression(points:Point[],origin:Point,x:(p:Point)=>number[],damping:number){
  const at=x(origin),n=at.length,m=origin.residuals.length;
  const near=points.map(p=>{const dx=x(p).map((v,i)=>v-at[i]);return{p,dx,d:dot(dx,dx)};})
    .filter(p=>p.d>1e-10).sort((a,b)=>a.d-b.d).slice(0,40);
  const matrix=Array.from({length:n},(_,i)=>Array.from({length:n+m},(_,j)=>i===j?damping:0));
  const information=Array(n).fill(0);
  for(const {p,dx,d} of near){
    const weight=1/(1+d)**2;
    for(let i=0;i<n;i++){
      information[i]+=weight*dx[i]*dx[i];
      for(let j=0;j<n;j++)matrix[i][j]+=weight*dx[i]*dx[j];
      for(let r=0;r<m;r++)matrix[i][n+r]+=weight*dx[i]*(p.residuals[r]-origin.residuals[r]);
    }
  }
  for(let d=0;d<n;d++){
    let pivot=d;for(let i=d+1;i<n;i++)if(Math.abs(matrix[i][d])>Math.abs(matrix[pivot][d]))pivot=i;
    [matrix[d],matrix[pivot]]=[matrix[pivot],matrix[d]];
    const v=matrix[d][d];if(!Number.isFinite(v)||Math.abs(v)<1e-14)return null;
    for(let j=d;j<n+m;j++)matrix[d][j]/=v;
    for(let i=0;i<n;i++)if(i!==d){const f=matrix[i][d];for(let j=d;j<n+m;j++)matrix[i][j]-=f*matrix[d][j];}
  }
  return{jac:Array.from({length:m},(_,r)=>matrix.map(row=>row[n+r])),information};
}
export function searchArcResponse(input:Input){
  const {keys,scale,allowance,evaluate,best,value}=input,n=keys.length;
  const x=(p:Point)=>keys.map(key=>value(p.c,key)/scale[key]);
  const propose=(origin:Point,step:number[])=>{const c={...origin.c};keys.forEach((key,i)=>c[key]=value(origin.c,key)+step[i]*scale[key]);return c;};
  let used=0,trust=1,misses=0,jac:number[][]|null=null,refreshes=0,updates=0,improvements=0;
  const update=(origin:Point,next:Point)=>{
    if(!jac)return;const a=x(origin),dx=x(next).map((v,i)=>v-a[i]),norm=dot(dx,dx);if(norm<1e-10)return;
    for(let r=0;r<jac.length;r++){
      const error=next.residuals[r]-origin.residuals[r]-dot(jac[r],dx);
      for(let i=0;i<n;i++)jac[r][i]+=.8*error*dx[i]/norm;
    }
    updates++;
  };
  while(used<allowance){
    if(input.mode==='broyden'&&(!jac||misses>=3)&&used+2*n<allowance){
      const origin=best(),at=x(origin);jac=origin.residuals.map(()=>Array(n).fill(0));
      for(let d=0;d<n;d++){
        const step=Array(n).fill(0);step[d]=trust;
        const a=evaluate(propose(origin,step));step[d]=-trust;const b=evaluate(propose(origin,step));used+=2;
        const da=a?x(a)[d]-at[d]:0,db=b?x(b)[d]-at[d]:0;
        for(let r=0;r<jac.length;r++)jac[r][d]=a&&b&&Math.abs(da-db)>1e-10?(a.residuals[r]-b.residuals[r])/(da-db):
          a&&Math.abs(da)>1e-10?(a.residuals[r]-origin.residuals[r])/da:b&&Math.abs(db)>1e-10?(b.residuals[r]-origin.residuals[r])/db:0;
      }
      update(origin,best());refreshes++;misses=0;input.retain();
    }
    const origin=best();let step:number[]|null=null;
    if(input.mode==='regression'){
      const fitted=regression(input.observations(),origin,x,.0002);
      jac=fitted?.jac??null;
      if(fitted&&(used%5===0||misses>=3)){
        let d=0;for(let i=1;i<n;i++)if(fitted.information[i]<fitted.information[d])d=i;
        step=Array(n).fill(0);step[d]=(used%2?-1:1)*trust;refreshes++;
      }
    }
    if(!step&&jac)step=arcResponseStep(jac,origin.residuals,input.damping/Math.max(.05,trust*trust));
    if(!step||dot(step,step)<1e-10){step=Array(n).fill(0);step[Math.floor(used/2)%n]=(used%2?-1:1)*trust;}
    step=step.map(v=>Math.max(-3*trust,Math.min(3*trust,v)));
    const candidate=evaluate(propose(origin,step));used++;
    if(candidate&&input.mode==='broyden')update(origin,candidate);
    if(best().cost<origin.cost-1e-12){improvements++;misses=0;trust=Math.min(2,trust*1.25);}
    else{misses++;trust=Math.max(.125,trust*.5);}
    input.retain();
  }
  return{used,refreshes,updates,improvements};
}
